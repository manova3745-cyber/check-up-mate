import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import Index from "./pages/Index.tsx";
import AuthPage from "./pages/AuthPage.tsx";
import ResetPasswordPage from "./pages/ResetPasswordPage.tsx";
import DashboardPage from "./pages/DashboardPage.tsx";
import PharmaciesPage from "./pages/PharmaciesPage.tsx";
import AdminPharmaciesPage from "./pages/AdminPharmaciesPage.tsx";
import NotFound from "./pages/NotFound.tsx";
import MobileInstallGate from "./components/MobileInstallGate";
import type { Language } from "@/lib/i18n";

const queryClient = new QueryClient();

const AppRoutes = () => {
  const { user, loading } = useAuth();
  const [language, setLanguage] = useState<Language>("en");
  const toggleLanguage = () => setLanguage((l) => (l === "en" ? "ta" : "en"));

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <Routes>
        <Route path="/reset-password" element={<ResetPasswordPage language={language} />} />
        <Route path="*" element={<AuthPage language={language} onToggleLanguage={toggleLanguage} />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/dashboard" element={<DashboardPage />} />
      <Route path="/pharmacies" element={<PharmaciesPage />} />
      <Route path="/admin/pharmacies" element={<AdminPharmaciesPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage language={language} />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <MobileInstallGate>
            <AppRoutes />
          </MobileInstallGate>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;