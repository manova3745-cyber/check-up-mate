import { useState, useMemo } from "react";
import { format } from "date-fns";
import { CalendarIcon, User, Save } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Props {
  userId: string;
  language: "en" | "ta";
  dob: Date | null;
  weight: number | null;
  height: number | null;
  age: number | null;
  onChange: (next: { dob: Date | null; weight: number | null; height: number | null; age: number | null }) => void;
}

function calcAge(dob: Date): number {
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return Math.max(0, age);
}

// Returns true when the birthday has NOT yet occurred this year, meaning age was rounded down by 1
function birthdayPending(dob: Date): boolean {
  const today = new Date();
  if (today.getFullYear() === dob.getFullYear()) return false;
  const m = today.getMonth() - dob.getMonth();
  return m < 0 || (m === 0 && today.getDate() < dob.getDate());
}

const MIN_AGE_YEARS = 1;

const ProfilePopover = ({ userId, language, dob, weight, height, age, onChange }: Props) => {
  const [open, setOpen] = useState(false);
  const [localDob, setLocalDob] = useState<Date | null>(dob);
  const [localWeight, setLocalWeight] = useState<string>(weight?.toString() ?? "");
  const [localHeight, setLocalHeight] = useState<string>(height?.toString() ?? "");
  const [saving, setSaving] = useState(false);

  const labels = language === "ta"
    ? {
        title: "உங்கள் சுயவிவரம்", dob: "பிறந்த தேதி", weight: "எடை (கிலோ)", height: "உயரம் (செமீ)",
        save: "சேமி", pick: "தேதியைத் தேர்வு செய்", years: "வயது",
        pending: "இந்த ஆண்டு பிறந்தநாள் இன்னும் வரவில்லை — வயது ஒன்று குறைக்கப்பட்டது",
        future: "எதிர்கால தேதியை தேர்வு செய்ய முடியாது",
        tooYoung: `குறைந்தபட்சம் ${MIN_AGE_YEARS} வயது தேவை`,
      }
    : {
        title: "Your profile", dob: "Date of birth", weight: "Weight (kg)", height: "Height (cm)",
        save: "Save", pick: "Pick a date", years: "years",
        pending: "Birthday not yet this year — age rounded down by 1",
        future: "Date of birth cannot be in the future",
        tooYoung: `You must be at least ${MIN_AGE_YEARS} year old`,
      };

  const previewAge = localDob ? calcAge(localDob) : null;
  const showPending = localDob ? birthdayPending(localDob) : false;

  const dobError = useMemo(() => {
    if (!localDob) return null;
    if (localDob > new Date()) return labels.future;
    if (calcAge(localDob) < MIN_AGE_YEARS) return labels.tooYoung;
    return null;
  }, [localDob, labels.future, labels.tooYoung]);

  const ageHintForChip = age !== null && dob && birthdayPending(dob)
    ? (language === "ta" ? "*" : "*")
    : "";

  const handleSave = async () => {
    if (dobError) {
      toast.error(dobError);
      return;
    }
    setSaving(true);
    const w = localWeight ? Number(localWeight) : null;
    const h = localHeight ? Number(localHeight) : null;
    const ageNow = localDob ? calcAge(localDob) : null;
    // Optimistic update
    onChange({ dob: localDob, weight: w, height: h, age: ageNow });
    const { error } = await supabase
      .from("profiles")
      .update({
        date_of_birth: localDob ? format(localDob, "yyyy-MM-dd") : null,
        weight_kg: w,
        height_cm: h,
      })
      .eq("user_id", userId);
    setSaving(false);
    if (error) toast.error(error.message);
    else {
      toast.success(language === "ta" ? "சேமிக்கப்பட்டது" : "Saved");
      setOpen(false);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          className="inline-flex items-center gap-1.5 text-[11px] font-medium px-2 py-1 rounded-full bg-primary/10 text-primary hover:bg-primary/15 transition-colors"
          title={age !== null && dob && birthdayPending(dob)
            ? `${labels.title} — ${labels.pending}`
            : labels.title}
        >
          <User className="w-3 h-3" />
          {age !== null ? `${age}y${ageHintForChip}` : labels.dob}
          {weight ? ` · ${weight}kg` : ""}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-3 z-[60]" align="end">
        <h4 className="text-sm font-semibold text-foreground mb-3">{labels.title}</h4>

        <label className="text-xs font-medium text-muted-foreground">{labels.dob}</label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn("w-full mt-1 justify-start text-left font-normal", !localDob && "text-muted-foreground")}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {localDob ? format(localDob, "PPP") : labels.pick}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 z-[80]" align="start">
            <Calendar
              mode="single"
              selected={localDob ?? undefined}
              onSelect={(d) => setLocalDob(d ?? null)}
              captionLayout="dropdown-buttons"
              fromYear={1920}
              toYear={new Date().getFullYear()}
              defaultMonth={localDob ?? new Date(2000, 0, 1)}
              disabled={(d) => d > new Date() || d < new Date("1920-01-01")}
              initialFocus
              className={cn("p-3 pointer-events-auto")}
            />
          </PopoverContent>
        </Popover>

        {previewAge !== null && (
          <>
            <p className="text-xs text-muted-foreground mt-1.5">
              {labels.years}: <span className="font-semibold text-foreground">{previewAge}</span>
            </p>
            {showPending && !dobError && (
              <p className="text-[10px] text-muted-foreground italic mt-0.5">{labels.pending}</p>
            )}
          </>
        )}
        {dobError && (
          <p className="text-[11px] text-destructive mt-1">{dobError}</p>
        )}

        <label className="text-xs font-medium text-muted-foreground mt-3 block">{labels.weight}</label>
        <input
          type="number" min={0} max={300} step={0.1}
          value={localWeight}
          onChange={(e) => setLocalWeight(e.target.value)}
          className="mt-1 w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
        />

        <label className="text-xs font-medium text-muted-foreground mt-3 block">{labels.height}</label>
        <input
          type="number" min={30} max={250} step={0.1}
          value={localHeight}
          onChange={(e) => setLocalHeight(e.target.value)}
          className="mt-1 w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
        />

        <Button onClick={handleSave} disabled={saving || !!dobError} className="w-full mt-3">
          <Save className="w-4 h-4 mr-2" /> {labels.save}
        </Button>
      </PopoverContent>
    </Popover>
  );
};

export default ProfilePopover;