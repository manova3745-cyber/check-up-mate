import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { MapPin, Phone, Siren, Stethoscope, Leaf, Sprout, Moon, Download } from "lucide-react";
import HospitalMapModal from "./HospitalMapModal";
import { jsPDF } from "jspdf";

interface ChatMessageProps {
  role: "user" | "assistant";
  content: string;
}

// Known hospital names to detect in text
const HOSPITAL_PATTERNS = [
  /Apollo/i, /Fortis/i, /AIIMS/i, /Government.*Hospital/i, /District.*Hospital/i,
  /National Institute of Siddha/i, /NIS.*Chennai/i, /Government Siddha Hospital/i,
  /Government Ayurveda Hospital/i, /All India Institute of Ayurveda/i,
  /அரசு.*மருத்துவமனை/i, /அப்பல்லோ/i, /ஃபோர்டிஸ/i,
  /தேசிய சித்த மருத்துவ நிறுவனம்/i,
];

function extractHospitalNames(text: string): string[] {
  const hospitals: string[] = [];
  const lines = text.split("\n");
  for (const line of lines) {
    for (const pattern of HOSPITAL_PATTERNS) {
      const match = line.match(pattern);
      if (match && !hospitals.includes(match[0])) {
        // Get a more complete name from the line context
        const cleanLine = line.replace(/[*#\-•]/g, "").trim();
        // Try to extract the hospital name portion
        const nameMatch = cleanLine.match(/([A-Z][A-Za-z\s]+(?:Hospital|Institute|Centre|Center|Medical College|AIIMS|NIS))/i);
        if (nameMatch && !hospitals.includes(nameMatch[1].trim())) {
          hospitals.push(nameMatch[1].trim());
        } else if (!hospitals.some(h => h.includes(match[0]))) {
          hospitals.push(match[0]);
        }
      }
    }
  }
  return hospitals.slice(0, 4); // Max 4
}

const SEVERITY_RE = /\[SEVERITY:\s*(low|moderate|high|emergency)\]/i;

const SYSTEMS = [
  { key: "ALLOPATHY", label: "Allopathy", color: "from-sky-500/15 to-sky-500/5 border-sky-500/30 text-sky-700", Icon: Stethoscope },
  { key: "SIDDHA",    label: "Siddha",    color: "from-emerald-500/15 to-emerald-500/5 border-emerald-500/30 text-emerald-700", Icon: Leaf },
  { key: "AYURVEDA",  label: "Ayurveda",  color: "from-amber-500/15 to-amber-500/5 border-amber-500/30 text-amber-700", Icon: Sprout },
  { key: "UNANI",     label: "Unani",     color: "from-violet-500/15 to-violet-500/5 border-violet-500/30 text-violet-700", Icon: Moon },
] as const;

function extractPrescriptions(text: string) {
  // Matches blocks: === PRESCRIPTION: ALLOPATHY === ... up to next === PRESCRIPTION or end of fence
  const result: { system: string; body: string }[] = [];
  // Strip code fences first to operate on raw content
  const re = /===\s*PRESCRIPTION:\s*([A-Z]+)\s*===([\s\S]*?)(?=(?:===\s*PRESCRIPTION:|```|$))/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    const sys = m[1].trim().toUpperCase();
    const body = m[2].trim();
    if (body) result.push({ system: sys, body });
  }
  return result;
}

function stripPrescriptionBlocks(text: string) {
  // Remove the entire fenced code block(s) that contain PRESCRIPTION cards so markdown renderer doesn't double-print
  return text.replace(/```[\s\S]*?===\s*PRESCRIPTION:[\s\S]*?```/g, "").replace(/===\s*PRESCRIPTION:[\s\S]*?(?===\s*PRESCRIPTION:|$)/g, "").trim();
}

const ChatMessage = ({ role, content }: ChatMessageProps) => {
  const [mapHospital, setMapHospital] = useState<string | null>(null);

  // Extract & strip severity tag from assistant messages
  let displayContent = content;
  let severity: string | null = null;
  if (role === "assistant") {
    const m = content.match(SEVERITY_RE);
    if (m) {
      severity = m[1].toLowerCase();
      displayContent = content.replace(SEVERITY_RE, "").trim();
    } else if (/EMERGENCY ALERT|அவசர எச்சரிக்கை/i.test(content)) {
      severity = "emergency";
    }
  }

  const hospitals = role === "assistant" ? extractHospitalNames(displayContent) : [];
  const isEmergency = severity === "emergency";

  const prescriptions = useMemo(
    () => (role === "assistant" ? extractPrescriptions(displayContent) : []),
    [role, displayContent]
  );
  const cleanedMarkdown = useMemo(
    () => (prescriptions.length ? stripPrescriptionBlocks(displayContent) : displayContent),
    [prescriptions.length, displayContent]
  );

  const downloadPrescriptionPdf = () => {
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 40;
    let y = margin;

    // Header
    doc.setFillColor(30, 58, 138);
    doc.rect(0, 0, pageW, 70, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.text("MediCare AI", margin, 32);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text("Prescription summary", margin, 50);
    doc.text(new Date().toLocaleString(), pageW - margin, 50, { align: "right" });

    y = 100;
    doc.setTextColor(15, 23, 42);

    prescriptions.forEach(({ system, body }) => {
      const meta = SYSTEMS.find((s) => s.key === system) || SYSTEMS[0];
      if (y > pageH - 120) { doc.addPage(); y = margin; }

      doc.setFont("helvetica", "bold");
      doc.setFontSize(13);
      doc.setTextColor(30, 58, 138);
      doc.text(`Rx — ${meta.label}`, margin, y);
      y += 8;
      doc.setDrawColor(30, 58, 138);
      doc.setLineWidth(0.8);
      doc.line(margin, y, pageW - margin, y);
      y += 14;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      const lines = doc.splitTextToSize(body, pageW - margin * 2);
      lines.forEach((line: string) => {
        if (y > pageH - margin) { doc.addPage(); y = margin; }
        doc.text(line, margin, y);
        y += 15;
      });
      y += 18;
    });

    // Footer disclaimer on every page
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(
        "This is not a medical diagnosis. Consult a qualified doctor before taking any medicine.",
        pageW / 2,
        pageH - 18,
        { align: "center" },
      );
    }

    doc.save(`MediCare-AI-Prescription-${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  if (role === "user") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: [0.2, 0, 0, 1] }}
        className="flex justify-end"
      >
        <div className="max-w-[85%] px-5 py-3 bg-primary text-primary-foreground rounded-[20px] rounded-br-lg">
          <p className="text-[15px] leading-relaxed">{content}</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.2, 0, 0, 1] }}
      className="flex justify-start"
    >
      <div
        className={`max-w-[85%] p-5 rounded-[20px] rounded-bl-lg ${
          isEmergency ? "bg-destructive/5 border-2 border-destructive/40" : "bg-card"
        }`}
        style={{ boxShadow: "var(--card-shadow)" }}
      >
        <div className="prose prose-sm prose-slate max-w-none text-[15px] leading-relaxed text-muted-foreground [&_strong]:text-foreground [&_h3]:text-foreground [&_h3]:text-base [&_h3]:mt-4 [&_h3]:mb-2 [&_h4]:text-foreground [&_h4]:text-sm [&_ul]:my-2 [&_li]:my-0.5 [&_p]:my-1.5">
          <ReactMarkdown>{cleanedMarkdown}</ReactMarkdown>
        </div>

        {/* Doctor-style prescription cards — one per medical system */}
        {prescriptions.length > 0 && (
          <>
          <div className="mt-4 flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Prescriptions</p>
            <button
              onClick={downloadPrescriptionPdf}
              className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90"
            >
              <Download className="w-3.5 h-3.5" /> Download PDF
            </button>
          </div>
          <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {prescriptions.map(({ system, body }) => {
              const meta = SYSTEMS.find((s) => s.key === system) || SYSTEMS[0];
              const Icon = meta.Icon;
              return (
                <div
                  key={system}
                  className={`relative rounded-xl border bg-gradient-to-br ${meta.color} p-3 overflow-hidden`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide">
                      <Icon className="w-3.5 h-3.5" />
                      {meta.label}
                    </div>
                    <span className="text-[10px] font-mono opacity-70">Rx</span>
                  </div>
                  <pre className="text-[12px] leading-relaxed text-foreground whitespace-pre-wrap font-sans">{body}</pre>
                </div>
              );
            })}
          </div>
          </>
        )}

        {/* Emergency action buttons */}
        {isEmergency && (
          <div className="mt-4 pt-4 border-t border-destructive/30 grid grid-cols-1 sm:grid-cols-2 gap-2">
            <a
              href="tel:108"
              className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-destructive text-destructive-foreground text-sm font-semibold hover:opacity-90 transition-opacity animate-pulse"
            >
              <Phone className="w-4 h-4" /> Call Ambulance (108)
            </a>
            <button
              onClick={() => setMapHospital("Nearest Hospital")}
              className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-foreground text-background text-sm font-semibold hover:opacity-90 transition-opacity"
            >
              <Siren className="w-4 h-4" /> Find Nearest Hospital
            </button>
          </div>
        )}

        {/* Hospital navigation buttons */}
        {hospitals.length > 0 && (
          <div className="mt-3 pt-3 border-t border-border space-y-1.5">
            <p className="text-xs font-medium text-muted-foreground mb-1.5">📍 Navigate to hospital:</p>
            {hospitals.map((name) => (
              <button
                key={name}
                onClick={() => setMapHospital(name)}
                className="flex items-center gap-1.5 w-full text-left px-3 py-2 rounded-lg bg-primary/5 hover:bg-primary/10 transition-colors text-sm text-foreground"
              >
                <MapPin className="w-3.5 h-3.5 text-primary shrink-0" />
                <span className="truncate">{name}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {mapHospital && (
        <HospitalMapModal hospitalName={mapHospital} onClose={() => setMapHospital(null)} />
      )}
    </motion.div>
  );
};

export default ChatMessage;
