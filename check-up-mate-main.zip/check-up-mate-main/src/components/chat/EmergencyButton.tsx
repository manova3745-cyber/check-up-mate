import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Siren, Phone, MapPin, MessageSquare, X, Loader2, Navigation, AlertTriangle, ChevronRight, Check, ArrowLeft, List, BellRing, ThumbsUp, ThumbsDown, Pill, MoreHorizontal } from "lucide-react";
import HospitalMapModal from "./HospitalMapModal";

interface Props {
  language: "en" | "ta";
}

interface NearestHospital {
  name: string;
  lat: number;
  lon: number;
  address: string;
  distanceKm: number;
}

interface NearbyPharmacy {
  name: string;
  lat: number;
  lon: number;
  distanceKm: number;
  phone?: string;
}

interface CachedSOS {
  hospital: NearestHospital;
  candidates?: NearestHospital[];
  userPos: { lat: number; lon: number };
  savedAt: number;
}

const SOS_CACHE_KEY = "aura.sos.lastLookup";

function loadCachedSOS(): CachedSOS | null {
  try {
    const raw = localStorage.getItem(SOS_CACHE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as CachedSOS;
  } catch {
    return null;
  }
}

function saveCachedSOS(c: CachedSOS) {
  try { localStorage.setItem(SOS_CACHE_KEY, JSON.stringify(c)); } catch { /* ignore */ }
}

function formatRelative(ts: number, lang: "en" | "ta"): string {
  const mins = Math.max(0, Math.floor((Date.now() - ts) / 60000));
  if (lang === "ta") {
    if (mins < 1) return "இப்போதே";
    if (mins < 60) return `${mins} நிமிடம் முன்பு`;
    const h = Math.floor(mins / 60);
    return `${h} மணி நேரம் முன்பு`;
  }
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const h = Math.floor(mins / 60);
  return `${h} hr ago`;
}

const L = {
  en: {
    sos: "SOS",
    title: "Emergency Help",
    locating: "Getting your location & finding the nearest hospital…",
    locError: "We couldn't get your location. Please enable GPS and try again.",
    nearest: "Nearest hospital",
    distance: "Distance",
    call: "Call Ambulance (108)",
    sms: "Send Emergency SMS (112)",
    map: "Open Route in Maps",
    inApp: "View on map",
    smsHead: "EMERGENCY: I need urgent medical help.",
    cached: "Using last known hospital",
    refreshing: "Refreshing location…",
    chooseList: "Choose a different hospital",
    pickTitle: "Nearby hospitals",
    pickFor: "Pick one for SOS",
    back: "Back",
    confirmTitle: "Confirm hospital",
    confirmDesc: "We'll include this hospital in your emergency SMS.",
    confirmSend: "Confirm & Send SMS",
    fallbackHead: "Hospital not found yet — sending without it",
    fallbackSmsHead: "EMERGENCY: I need urgent medical help. Please send an ambulance.",
    fallbackSms: "Send basic SMS (112)",
    selected: "Selected",
    deliveryTitle: "Did your alert go through?",
    deliveryDesc: "Confirm whether the SMS was sent / the call connected. If not, we'll sound an alarm so people nearby can help.",
    delivered: "Yes, it was delivered",
    notDelivered: "No, it failed",
    deliveredOk: "Great — help is on the way.",
    alarmOn: "Alarm sounding — wave for help",
    stopAlarm: "Stop alarm",
    pharmacies: "Nearby pharmacies",
    pharmaciesEmpty: "No pharmacies found within 10 km.",
    viewPharmacies: "Find pharmacies",
    moreOptions: "More options",
    callDirect: "Tap = instant 108 call",
  },
  ta: {
    sos: "அவசரம்",
    title: "அவசர உதவி",
    locating: "உங்கள் இருப்பிடம் & அருகிலுள்ள மருத்துவமனையை தேடுகிறது…",
    locError: "உங்கள் இருப்பிடம் கிடைக்கவில்லை. GPS-ஐ இயக்கி மீண்டும் முயற்சிக்கவும்.",
    nearest: "அருகிலுள்ள மருத்துவமனை",
    distance: "தூரம்",
    call: "ஆம்புலன்ஸை அழை (108)",
    sms: "அவசர SMS அனுப்பு (112)",
    map: "Maps-இல் வழித்தடம்",
    inApp: "வரைபடத்தில் பார்",
    smsHead: "அவசரம்: எனக்கு உடனடி மருத்துவ உதவி தேவை.",
    cached: "கடைசி அறியப்பட்ட மருத்துவமனை",
    refreshing: "இருப்பிடம் புதுப்பிக்கப்படுகிறது…",
    chooseList: "வேறு மருத்துவமனையை தேர்வு செய்",
    pickTitle: "அருகிலுள்ள மருத்துவமனைகள்",
    pickFor: "SOS-க்கு ஒன்றை தேர்வு செய்",
    back: "பின்",
    confirmTitle: "மருத்துவமனையை உறுதிப்படுத்து",
    confirmDesc: "இந்த மருத்துவமனை உங்கள் அவசர SMS-இல் சேர்க்கப்படும்.",
    confirmSend: "உறுதி & SMS அனுப்பு",
    fallbackHead: "மருத்துவமனை இன்னும் கிடைக்கவில்லை — அது இல்லாமல் அனுப்பப்படுகிறது",
    fallbackSmsHead: "அவசரம்: எனக்கு உடனடி மருத்துவ உதவி தேவை. ஆம்புலன்ஸ் அனுப்பவும்.",
    fallbackSms: "அடிப்படை SMS அனுப்பு (112)",
    selected: "தேர்ந்தெடுக்கப்பட்டது",
    deliveryTitle: "உங்கள் எச்சரிக்கை சென்றதா?",
    deliveryDesc: "SMS அனுப்பப்பட்டதா / அழைப்பு இணைந்ததா என உறுதிப்படுத்தவும். இல்லையெனில், அருகில் உள்ளவர்கள் கேட்க அலாரத்தை ஒலிப்போம்.",
    delivered: "ஆம், சென்றது",
    notDelivered: "இல்லை, தோல்வி",
    deliveredOk: "சிறப்பு — உதவி வருகிறது.",
    alarmOn: "அலாரம் ஒலிக்கிறது — உதவிக்காக கையசை",
    stopAlarm: "அலாரத்தை நிறுத்து",
    pharmacies: "அருகிலுள்ள மருந்தகங்கள்",
    pharmaciesEmpty: "10 கிமீ-க்குள் மருந்தகம் இல்லை.",
    viewPharmacies: "மருந்தகங்களை தேடு",
    moreOptions: "மேலும் விருப்பங்கள்",
    callDirect: "தட்டினால் 108-ஐ உடனே அழைக்கும்",
  },
} as const;

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const EmergencyButton = ({ language }: Props) => {
  const [open, setOpen] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [userPos, setUserPos] = useState<{ lat: number; lon: number } | null>(null);
  const [hospital, setHospital] = useState<NearestHospital | null>(null);
  const [candidates, setCandidates] = useState<NearestHospital[]>([]);
  const [pharmacies, setPharmacies] = useState<NearbyPharmacy[]>([]);
  const [pharmaciesLoading, setPharmaciesLoading] = useState(false);
  const [cachedAt, setCachedAt] = useState<number | null>(null);
  const [view, setView] = useState<"main" | "list" | "confirm" | "delivery" | "alarm" | "pharmacies">("main");
  const t = L[language];
  const audioCtxRef = useRef<AudioContext | null>(null);
  const alarmStopRef = useRef<(() => void) | null>(null);

  const startAlarm = () => {
    try {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = audioCtxRef.current ?? new Ctx();
      audioCtxRef.current = ctx;
      const gain = ctx.createGain();
      gain.gain.value = 0.25;
      gain.connect(ctx.destination);
      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.connect(gain);
      const start = ctx.currentTime;
      // Two-tone siren sweep, looped via setInterval
      osc.frequency.setValueAtTime(700, start);
      osc.start();
      const tick = () => {
        const now = ctx.currentTime;
        osc.frequency.cancelScheduledValues(now);
        osc.frequency.setValueAtTime(700, now);
        osc.frequency.linearRampToValueAtTime(1100, now + 0.4);
        osc.frequency.linearRampToValueAtTime(700, now + 0.8);
      };
      tick();
      const id = window.setInterval(tick, 800);
      // Vibrate too if supported
      try { (navigator as Navigator & { vibrate?: (p: number[]) => boolean }).vibrate?.([400, 200, 400, 200, 400]); } catch { /* noop */ }
      alarmStopRef.current = () => {
        window.clearInterval(id);
        try { osc.stop(); } catch { /* noop */ }
        try { gain.disconnect(); } catch { /* noop */ }
      };
    } catch {
      // ignore — audio may be blocked
    }
  };

  const stopAlarm = () => {
    alarmStopRef.current?.();
    alarmStopRef.current = null;
  };

  useEffect(() => () => stopAlarm(), []);

  // When the user opens the SOS sheet, immediately request location + find nearest hospital
  useEffect(() => {
    if (!open) return;
    setError(null);
    setView("main");
    // Hydrate from last lookup so SMS/Call work instantly
    const cached = loadCachedSOS();
    if (cached) {
      setHospital(cached.hospital);
      setCandidates(cached.candidates ?? [cached.hospital]);
      setUserPos(cached.userPos);
      setCachedAt(cached.savedAt);
    } else {
      setHospital(null);
      setCandidates([]);
      setUserPos(null);
      setCachedAt(null);
    }
    setLoading(true);

    if (!navigator.geolocation) {
      if (!cached) setError(t.locError);
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        setUserPos({ lat, lon });
        try {
          // Find nearby hospitals via Overpass
          const query = `[out:json][timeout:15];(node["amenity"="hospital"](around:10000,${lat},${lon});way["amenity"="hospital"](around:10000,${lat},${lon}););out center 10;`;
          const res = await fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`);
          const data = await res.json();
          const elements = (data.elements || []) as Array<{
            lat?: number; lon?: number; center?: { lat: number; lon: number }; tags?: Record<string, string>;
          }>;
          const candidates = elements
            .map((e) => ({
              lat: e.lat ?? e.center?.lat,
              lon: e.lon ?? e.center?.lon,
              tags: e.tags || {},
            }))
            .filter((e): e is { lat: number; lon: number; tags: Record<string, string> } => e.lat != null && e.lon != null);

          if (candidates.length === 0) throw new Error("no-hospital");
          candidates.sort((a, b) => haversine(lat, lon, a.lat, a.lon) - haversine(lat, lon, b.lat, b.lon));
          const top5 = candidates.slice(0, 5);

          // Reverse geocode the closest one only (fast); others use tag-based addresses
          let topAddress = "";
          try {
            const geo = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${top5[0].lat}&lon=${top5[0].lon}&zoom=18`);
            const gd = await geo.json();
            topAddress = gd.display_name || "";
          } catch { /* ignore */ }

          const buildHospital = (c: typeof top5[number], idx: number): NearestHospital => {
            const tagAddr = [c.tags["addr:housenumber"], c.tags["addr:street"], c.tags["addr:city"], c.tags["addr:state"]]
              .filter(Boolean).join(", ");
            return {
              name: c.tags["name"] || (language === "ta" ? "அருகிலுள்ள மருத்துவமனை" : "Nearby Hospital"),
              lat: c.lat,
              lon: c.lon,
              address: tagAddr || (idx === 0 ? topAddress : "") || `${c.lat.toFixed(5)}, ${c.lon.toFixed(5)}`,
              distanceKm: haversine(lat, lon, c.lat, c.lon),
            };
          };
          const list = top5.map(buildHospital);
          setCandidates(list);
          // Preserve any user-picked hospital if still in fresh list, else use closest
          setHospital((prev) => {
            if (prev) {
              const match = list.find((h) => Math.abs(h.lat - prev.lat) < 1e-5 && Math.abs(h.lon - prev.lon) < 1e-5);
              if (match) return match;
            }
            return list[0];
          });
          const chosen = list[0];
          saveCachedSOS({ hospital: chosen, candidates: list, userPos: { lat, lon }, savedAt: Date.now() });
          setCachedAt(Date.now());
        } catch {
          if (!cached) setError(language === "ta" ? "மருத்துவமனை கிடைக்கவில்லை. 108-ஐ அழைக்கவும்." : "No hospital found nearby. Please call 108.");
        } finally {
          setLoading(false);
        }
      },
      () => {
        if (!cached) setError(t.locError);
        setLoading(false);
      },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  }, [open, language, t.locError]);

  const mapsUrl = hospital && userPos
    ? `https://www.google.com/maps/dir/?api=1&origin=${userPos.lat},${userPos.lon}&destination=${hospital.lat},${hospital.lon}&travelmode=driving`
    : userPos
      ? `https://www.google.com/maps/search/hospital/@${userPos.lat},${userPos.lon},15z`
      : "https://www.google.com/maps/search/hospital";

  const smsBody = (() => {
    const lines: string[] = [t.smsHead];
    if (userPos) lines.push(`${language === "ta" ? "என் இருப்பிடம்" : "My location"}: https://maps.google.com/?q=${userPos.lat},${userPos.lon}`);
    if (hospital) {
      lines.push(`${language === "ta" ? "அருகிலுள்ள மருத்துவமனை" : "Nearest hospital"}: ${hospital.name}`);
      lines.push(`${language === "ta" ? "முகவரி" : "Address"}: ${hospital.address}`);
      lines.push(`${language === "ta" ? "வழித்தடம்" : "Route"}: ${mapsUrl}`);
    }
    return lines.join("\n");
  })();

  // Fallback SMS used when no hospital is known (lookup still loading or failed)
  const fallbackSmsBody = (() => {
    const lines: string[] = [language === "ta" ? L.ta.fallbackSmsHead : L.en.fallbackSmsHead];
    if (userPos) lines.push(`${language === "ta" ? "என் இருப்பிடம்" : "My location"}: https://maps.google.com/?q=${userPos.lat},${userPos.lon}`);
    return lines.join("\n");
  })();

  const pickHospital = (h: NearestHospital) => {
    setHospital(h);
    if (userPos) saveCachedSOS({ hospital: h, candidates, userPos, savedAt: cachedAt ?? Date.now() });
    setView("main");
  };

  const askDelivery = () => setView("delivery");

  const loadPharmacies = async () => {
    if (!userPos) return;
    setView("pharmacies");
    setPharmaciesLoading(true);
    try {
      const q = `[out:json][timeout:15];(node["amenity"="pharmacy"](around:10000,${userPos.lat},${userPos.lon});way["amenity"="pharmacy"](around:10000,${userPos.lat},${userPos.lon}););out center 25;`;
      const res = await fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(q)}`);
      const data = await res.json();
      const els = (data.elements || []) as Array<{ lat?: number; lon?: number; center?: { lat: number; lon: number }; tags?: Record<string, string> }>;
      const list: NearbyPharmacy[] = [];
      for (const e of els) {
        const lat = e.lat ?? e.center?.lat;
        const lon = e.lon ?? e.center?.lon;
        if (lat == null || lon == null) continue;
        const phone = e.tags?.phone || e.tags?.["contact:phone"];
        const item: NearbyPharmacy = {
          name: e.tags?.name || (language === "ta" ? "மருந்தகம்" : "Pharmacy"),
          lat, lon,
          distanceKm: haversine(userPos.lat, userPos.lon, lat, lon),
        };
        if (phone) item.phone = phone;
        list.push(item);
      }
      list.sort((a, b) => a.distanceKm - b.distanceKm);
      list.splice(15);
      setPharmacies(list);
    } finally {
      setPharmaciesLoading(false);
    }
  };

  return (
    <>
      {/* Always-visible SOS: tap = instant 108 call. Long-press / "More" opens the sheet. */}
      <div className="fixed bottom-24 right-5 z-[90] flex flex-col items-center gap-1.5">
        <motion.a
          href="tel:108"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="relative w-16 h-16 rounded-full bg-destructive text-destructive-foreground shadow-lg flex items-center justify-center"
          style={{ boxShadow: "0 8px 24px hsl(var(--destructive) / 0.45)" }}
          aria-label={t.call}
          title={t.callDirect}
        >
          <span className="absolute inset-0 rounded-full bg-destructive/40 animate-ping" />
          <Siren className="w-7 h-7 relative" />
          <span className="absolute -bottom-5 text-[10px] font-bold text-destructive">{t.sos}</span>
        </motion.a>
        <button
          onClick={() => setOpen(true)}
          className="mt-4 inline-flex items-center gap-1 h-7 px-2.5 rounded-full bg-card border border-border text-[10px] font-semibold text-foreground shadow-sm hover:bg-secondary"
          aria-label={t.moreOptions}
        >
          <MoreHorizontal className="w-3 h-3" /> {t.moreOptions}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
            onClick={() => { stopAlarm(); setOpen(false); }}
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }}
              className="bg-card rounded-2xl shadow-xl w-full max-w-sm overflow-hidden border-2 border-destructive/30"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b border-border bg-destructive/5">
                <div className="flex items-center gap-2">
                  <Siren className="w-5 h-5 text-destructive animate-pulse" />
                  <h3 className="text-sm font-bold text-foreground">{t.title}</h3>
                </div>
                <button onClick={() => setOpen(false)} className="p-1.5 rounded-lg hover:bg-secondary">
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              <div className="p-4 space-y-3">
              {view === "main" && (<>
                {loading && !hospital && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" /> {t.locating}
                  </div>
                )}
                {loading && hospital && (
                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                    <Loader2 className="w-3 h-3 animate-spin text-primary" /> {t.refreshing}
                  </div>
                )}

                {error && (
                  <div className="flex items-start gap-2 text-sm text-destructive bg-destructive/5 p-3 rounded-lg">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /> <span>{error}</span>
                  </div>
                )}

                {hospital && (
                  <div className="rounded-xl bg-primary/5 border border-primary/15 p-3 space-y-1.5">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-primary">
                      <MapPin className="w-3.5 h-3.5" /> {t.nearest}
                    </div>
                    <p className="text-sm font-semibold text-foreground leading-snug">{hospital.name}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{hospital.address}</p>
                    <p className="text-xs text-foreground"><Navigation className="inline w-3 h-3 mr-1 text-primary" />
                      {t.distance}: <span className="font-semibold">{hospital.distanceKm.toFixed(1)} km</span></p>
                    {cachedAt && (
                      <p className="text-[10px] text-muted-foreground italic">
                        {t.cached} · {formatRelative(cachedAt, language)}
                      </p>
                    )}
                    <div className="flex items-center gap-3 pt-0.5">
                      <button
                        onClick={() => { setShowMap(true); setOpen(false); }}
                        className="text-[11px] text-primary font-medium underline-offset-2 hover:underline"
                      >{t.inApp}</button>
                      {candidates.length > 1 && (
                        <button
                          onClick={() => setView("list")}
                          className="text-[11px] text-primary font-medium inline-flex items-center gap-1 underline-offset-2 hover:underline"
                        >
                          <List className="w-3 h-3" /> {t.chooseList}
                        </button>
                      )}
                    </div>
                    <button
                      onClick={loadPharmacies}
                      className="mt-2 inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-emerald-500/10 text-emerald-700 text-[11px] font-semibold hover:bg-emerald-500/20"
                    >
                      <Pill className="w-3.5 h-3.5" /> {t.viewPharmacies}
                    </button>
                  </div>
                )}

                <div className="space-y-2 pt-1">
                  <a
                    href="tel:108"
                    onClick={() => setTimeout(askDelivery, 500)}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl bg-destructive text-destructive-foreground font-semibold text-sm hover:opacity-90 transition-opacity"
                  >
                    <Phone className="w-4 h-4" /> {t.call}
                  </a>
                  {hospital ? (
                    <button
                      onClick={() => setView("confirm")}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-foreground text-background font-semibold text-sm hover:opacity-90 transition-opacity"
                    >
                      <MessageSquare className="w-4 h-4" /> {t.sms}
                      <ChevronRight className="w-4 h-4 ml-auto opacity-70" />
                    </button>
                  ) : (
                    <a
                      href={`sms:112?body=${encodeURIComponent(fallbackSmsBody)}`}
                      onClick={() => setTimeout(askDelivery, 500)}
                      className="flex items-center gap-3 px-4 py-3 rounded-xl bg-foreground text-background font-semibold text-sm hover:opacity-90 transition-opacity"
                    >
                      <MessageSquare className="w-4 h-4" /> {t.fallbackSms}
                    </a>
                  )}
                  <a
                    href={mapsUrl}
                    target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-3 px-4 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity"
                  >
                    <MapPin className="w-4 h-4" /> {t.map}
                  </a>
                </div>
              </>)}

              {view === "list" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <button onClick={() => setView("main")} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                      <ArrowLeft className="w-3.5 h-3.5" /> {t.back}
                    </button>
                    <p className="text-[11px] text-muted-foreground">{t.pickFor}</p>
                  </div>
                  <h4 className="text-sm font-semibold text-foreground">{t.pickTitle}</h4>
                  {loading && candidates.length === 0 && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground py-2">
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-primary" /> {t.locating}
                    </div>
                  )}
                  <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                    {candidates.map((h, i) => {
                      const isActive = hospital
                        && Math.abs(h.lat - hospital.lat) < 1e-5
                        && Math.abs(h.lon - hospital.lon) < 1e-5;
                      return (
                        <button
                          key={`${h.lat}-${h.lon}-${i}`}
                          onClick={() => pickHospital(h)}
                          className={`w-full text-left px-3 py-2 rounded-lg border transition-colors ${
                            isActive ? "border-primary bg-primary/10" : "border-border hover:bg-secondary"
                          }`}
                        >
                          <div className="flex items-start gap-2">
                            <MapPin className="w-3.5 h-3.5 mt-0.5 text-primary shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">{h.name}</p>
                              <p className="text-[11px] text-muted-foreground truncate">{h.address}</p>
                              <p className="text-[11px] text-foreground mt-0.5">{h.distanceKm.toFixed(1)} km</p>
                            </div>
                            {isActive && <Check className="w-4 h-4 text-primary shrink-0" />}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {view === "confirm" && hospital && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <button onClick={() => setView("main")} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                      <ArrowLeft className="w-3.5 h-3.5" /> {t.back}
                    </button>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-foreground">{t.confirmTitle}</h4>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{t.confirmDesc}</p>
                  </div>
                  <div className="rounded-xl bg-primary/5 border border-primary/15 p-3 space-y-1">
                    <p className="text-[10px] uppercase tracking-wide font-semibold text-primary">{t.selected}</p>
                    <p className="text-sm font-semibold text-foreground">{hospital.name}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{hospital.address}</p>
                    <p className="text-xs text-foreground">{hospital.distanceKm.toFixed(1)} km</p>
                  </div>
                  <pre className="text-[10px] text-muted-foreground bg-secondary/40 rounded-lg p-2 max-h-28 overflow-y-auto whitespace-pre-wrap break-words">{smsBody}</pre>
                  {candidates.length > 1 && (
                    <button
                      onClick={() => setView("list")}
                      className="text-[11px] text-primary font-medium inline-flex items-center gap-1 hover:underline"
                    >
                      <List className="w-3 h-3" /> {t.chooseList}
                    </button>
                  )}
                  <a
                    href={`sms:112?body=${encodeURIComponent(smsBody)}`}
                    onClick={() => { setView("main"); setTimeout(askDelivery, 500); }}
                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-foreground text-background font-semibold text-sm hover:opacity-90 transition-opacity"
                  >
                    <Check className="w-4 h-4" /> {t.confirmSend}
                  </a>
                </div>
              )}

              {view === "delivery" && (
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold text-foreground">{t.deliveryTitle}</h4>
                  <p className="text-xs text-muted-foreground">{t.deliveryDesc}</p>
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => { setView("main"); }}
                      className="flex items-center justify-center gap-2 px-3 py-3 rounded-xl bg-emerald-500/15 text-emerald-700 font-semibold text-sm hover:bg-emerald-500/25 transition-colors border border-emerald-500/30"
                    >
                      <ThumbsUp className="w-4 h-4" /> {t.delivered}
                    </button>
                    <button
                      onClick={() => { startAlarm(); setView("alarm"); }}
                      className="flex items-center justify-center gap-2 px-3 py-3 rounded-xl bg-destructive/15 text-destructive font-semibold text-sm hover:bg-destructive/25 transition-colors border border-destructive/30"
                    >
                      <ThumbsDown className="w-4 h-4" /> {t.notDelivered}
                    </button>
                  </div>
                </div>
              )}

              {view === "alarm" && (
                <div className="space-y-3 text-center">
                  <motion.div
                    animate={{ scale: [1, 1.15, 1] }}
                    transition={{ repeat: Infinity, duration: 0.7 }}
                    className="mx-auto w-16 h-16 rounded-full bg-destructive/15 flex items-center justify-center"
                  >
                    <BellRing className="w-8 h-8 text-destructive" />
                  </motion.div>
                  <h4 className="text-sm font-bold text-destructive">{t.alarmOn}</h4>
                  <a
                    href="tel:108"
                    className="block px-4 py-3 rounded-xl bg-destructive text-destructive-foreground font-semibold text-sm"
                  >
                    <Phone className="inline w-4 h-4 mr-1" /> {t.call}
                  </a>
                  <button
                    onClick={() => { stopAlarm(); setView("main"); }}
                    className="w-full px-4 py-2.5 rounded-xl bg-secondary text-foreground font-medium text-sm"
                  >
                    {t.stopAlarm}
                  </button>
                </div>
              )}

              {view === "pharmacies" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <button onClick={() => setView("main")} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                      <ArrowLeft className="w-3.5 h-3.5" /> {t.back}
                    </button>
                  </div>
                  <h4 className="text-sm font-semibold text-foreground inline-flex items-center gap-1.5">
                    <Pill className="w-4 h-4 text-emerald-600" /> {t.pharmacies}
                  </h4>
                  {pharmaciesLoading && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground py-2">
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-primary" /> {t.locating}
                    </div>
                  )}
                  {!pharmaciesLoading && pharmacies.length === 0 && (
                    <p className="text-xs text-muted-foreground py-2">{t.pharmaciesEmpty}</p>
                  )}
                  <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                    {pharmacies.map((p, i) => {
                      const url = userPos
                        ? `https://www.google.com/maps/dir/?api=1&origin=${userPos.lat},${userPos.lon}&destination=${p.lat},${p.lon}&travelmode=driving`
                        : `https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lon}`;
                      return (
                        <div key={`${p.lat}-${p.lon}-${i}`} className="px-3 py-2 rounded-lg border border-border">
                          <div className="flex items-start gap-2">
                            <Pill className="w-3.5 h-3.5 mt-0.5 text-emerald-600 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-foreground truncate">{p.name}</p>
                              <p className="text-[11px] text-foreground mt-0.5">{p.distanceKm.toFixed(1)} km</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 mt-1.5">
                            <a href={url} target="_blank" rel="noopener noreferrer" className="text-[11px] text-primary font-medium hover:underline inline-flex items-center gap-1">
                              <Navigation className="w-3 h-3" /> {t.map}
                            </a>
                            {p.phone && (
                              <a href={`tel:${p.phone}`} className="text-[11px] text-emerald-700 font-medium hover:underline inline-flex items-center gap-1">
                                <Phone className="w-3 h-3" /> {p.phone}
                              </a>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {showMap && hospital && (
        <HospitalMapModal hospitalName={hospital.name} onClose={() => setShowMap(false)} />
      )}
    </>
  );
};

export default EmergencyButton;