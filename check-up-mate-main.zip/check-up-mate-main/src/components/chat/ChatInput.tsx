import { useState } from "react";
import { Send } from "lucide-react";
import { motion } from "framer-motion";

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
  placeholder?: string;
}

const ChatInput = ({ onSend, disabled, placeholder = "Describe your symptoms..." }: ChatInputProps) => {
  const [value, setValue] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
    setValue("");
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-3 p-4 bg-card border-t border-border">
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        className="flex-1 px-4 py-3 bg-secondary text-foreground placeholder:text-muted-foreground rounded-xl text-[15px] outline-none focus:ring-2 focus:ring-primary/20 transition-shadow disabled:opacity-50"
        maxLength={500}
      />
      <motion.button
        whileTap={{ scale: 0.94 }}
        type="submit"
        disabled={disabled || !value.trim()}
        className="p-3 bg-primary text-primary-foreground rounded-xl disabled:opacity-40 transition-opacity"
      >
        <Send className="w-5 h-5" />
      </motion.button>
    </form>
  );
};

export default ChatInput;
