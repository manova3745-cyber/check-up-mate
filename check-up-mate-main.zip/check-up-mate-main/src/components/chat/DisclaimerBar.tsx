import type { Language } from "@/lib/i18n";
import { translations } from "@/lib/i18n";

const DisclaimerBar = ({ language = "en" }: { language?: Language }) => {
  const T = translations[language];
  return (
    <div className="px-4 py-3 text-center">
      <p className="text-[11px] uppercase tracking-widest font-medium text-muted-foreground">
        {T.disclaimer}
      </p>
    </div>
  );
};

export default DisclaimerBar;
