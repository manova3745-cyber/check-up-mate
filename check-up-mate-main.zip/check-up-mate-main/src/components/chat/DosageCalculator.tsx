import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Calculator, Pill } from "lucide-react";

interface Props {
  defaultAge?: number | null;
  defaultWeight?: number | null;
  language: "en" | "ta";
  onClose: () => void;
  onAskAI: (prompt: string) => void;
}

const L = {
  en: {
    title: "Dosage Calculator",
    subtitle: "Get a safe dose based on age, weight & condition",
    age: "Age (years)",
    weight: "Weight (kg)",
    condition: "Condition / Symptom",
    conditionPh: "e.g. fever, body pain, cough",
    medicine: "Preferred medicine (optional)",
    medicinePh: "e.g. Paracetamol",
    quick: "Quick estimate",
    ask: "Get full prescription from MediCare AI",
    cat: "Category",
    child: "Child",
    adult: "Adult",
    elderly: "Elderly",
    note: "This is a rough guide. MediCare AI will give a full age & weight based prescription with timings.",
  },
  ta: {
    title: "மருந்து அளவு கணக்கீடு",
    subtitle: "வயது, எடை & நோய்க்கேற்ற பாதுகாப்பான அளவு",
    age: "வயது (ஆண்டுகள்)",
    weight: "எடை (கிலோ)",
    condition: "நோய் / அறிகுறி",
    conditionPh: "எ.கா. காய்ச்சல், உடல் வலி, இருமல்",
    medicine: "விரும்பிய மருந்து (விருப்பம்)",
    medicinePh: "எ.கா. பாராசிட்டமால்",
    quick: "விரைவு மதிப்பீடு",
    ask: "மெடிகேர் AIவிடம் முழு மருந்துச் சீட்டு கேள்",
    cat: "வகை",
    child: "குழந்தை",
    adult: "பெரியவர்",
    elderly: "முதியவர்",
    note: "இது தோராயமான வழிகாட்டி. மெடிகேர் AI முழு வயது & எடை அடிப்படையிலான மருந்துச் சீட்டை நேரத்துடன் தரும்.",
  },
} as const;

function category(age: number, lang: "en" | "ta") {
  const t = L[lang];
  if (age < 13) return t.child;
  if (age >= 65) return t.elderly;
  return t.adult;
}

// Very simple paracetamol-style estimate as a friendly preview only.
function estimate(age: number, weight: number) {
  if (!age || !weight) return null;
  const perDose = Math.round(Math.min(15 * weight, 1000));
  const max = age < 13 ? 4 : 4;
  return { perDose, frequency: max };
}

const DosageCalculator = ({ defaultAge, defaultWeight, language, onClose, onAskAI }: Props) => {
  const t = L[language];
  const [age, setAge] = useState<string>(defaultAge?.toString() ?? "");
  const [weight, setWeight] = useState<string>(defaultWeight?.toString() ?? "");
  const [condition, setCondition] = useState("");
  const [medicine, setMedicine] = useState("");

  const ageNum = Number(age);
  const weightNum = Number(weight);
  const est = estimate(ageNum, weightNum);

  const handleAsk = () => {
    if (!age || !weight || !condition.trim()) return;
    const prompt =
      language === "ta"
        ? `எனது வயது ${age}, எடை ${weight} கிலோ. நோய்: ${condition}.${medicine ? ` விரும்பிய மருந்து: ${medicine}.` : ""} துல்லியமான மருந்து அளவு, நேரம் மற்றும் முழு மருந்துச் சீட்டை தாருங்கள்.`
        : `I am ${age} years old, ${weight} kg. Condition: ${condition}.${medicine ? ` Preferred medicine: ${medicine}.` : ""} Please give exact dosage, timing and a full prescription.`;
    onAskAI(prompt);
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
          className="bg-card rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                <Calculator className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">{t.title}</h3>
                <p className="text-[11px] text-muted-foreground">{t.subtitle}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>

          <div className="p-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-muted-foreground">{t.age}</label>
                <input
                  type="number" min={0} max={120} value={age} onChange={(e) => setAge(e.target.value)}
                  className="mt-1 w-full h-10 px-3 rounded-lg border border-input bg-background text-sm"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground">{t.weight}</label>
                <input
                  type="number" min={0} max={300} value={weight} onChange={(e) => setWeight(e.target.value)}
                  className="mt-1 w-full h-10 px-3 rounded-lg border border-input bg-background text-sm"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">{t.condition}</label>
              <input
                value={condition} onChange={(e) => setCondition(e.target.value)} placeholder={t.conditionPh}
                className="mt-1 w-full h-10 px-3 rounded-lg border border-input bg-background text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">{t.medicine}</label>
              <input
                value={medicine} onChange={(e) => setMedicine(e.target.value)} placeholder={t.medicinePh}
                className="mt-1 w-full h-10 px-3 rounded-lg border border-input bg-background text-sm"
              />
            </div>

            {est && ageNum > 0 && weightNum > 0 && (
              <div className="rounded-xl bg-primary/5 border border-primary/15 p-3">
                <div className="flex items-center gap-2 mb-1.5">
                  <Pill className="w-4 h-4 text-primary" />
                  <span className="text-xs font-semibold text-foreground">{t.quick}</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {t.cat}: <span className="font-medium text-foreground">{category(ageNum, language)}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Paracetamol ≈ <span className="font-medium text-foreground">{est.perDose} mg</span>
                  {" "}× {est.frequency}/day
                </p>
                <p className="text-[11px] text-muted-foreground/80 mt-2 italic">{t.note}</p>
              </div>
            )}

            <button
              onClick={handleAsk}
              disabled={!age || !weight || !condition.trim()}
              className="w-full py-2.5 px-4 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {t.ask}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default DosageCalculator;