import { motion } from "framer-motion";

interface SymptomPillsProps {
  symptoms: string[];
  onSelect: (symptom: string) => void;
  disabled?: boolean;
}

const SymptomPills = ({ symptoms, onSelect, disabled }: SymptomPillsProps) => (
  <motion.div
    initial={{ opacity: 0, y: 8 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.25, ease: [0.2, 0, 0, 1], delay: 0.1 }}
    className="flex flex-wrap gap-2 justify-start"
  >
    {symptoms.map((symptom) => (
      <motion.button
        key={symptom}
        whileTap={{ scale: 0.96 }}
        onClick={() => onSelect(symptom)}
        disabled={disabled}
        className="px-4 py-2.5 bg-card text-foreground text-sm font-medium rounded-xl transition-colors hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed"
        style={{ boxShadow: "var(--card-shadow)" }}
      >
        {symptom}
      </motion.button>
    ))}
  </motion.div>
);

export default SymptomPills;
