import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Navigation, Clock, MapPin, Loader2, Phone, ExternalLink, AlertTriangle, Search, RotateCw, Crosshair } from "lucide-react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

interface HospitalMapModalProps {
  hospitalName: string;
  onClose: () => void;
}

interface RouteInfo {
  distance: string;
  duration: string;
}

interface NearbyPlace {
  name: string;
  lat: number;
  lon: number;
  distanceKm: number;
  phone?: string;
  kind: "hospital" | "pharmacy";
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const LAST_LOCATION_KEY = "hospital_map_last_manual_location";

type SavedLocation = { lat: number; lon: number; label?: string };

function loadSavedLocation(): SavedLocation | null {
  try {
    const raw = localStorage.getItem(LAST_LOCATION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SavedLocation;
    if (typeof parsed?.lat === "number" && typeof parsed?.lon === "number") return parsed;
  } catch { /* noop */ }
  return null;
}

function saveLocation(loc: SavedLocation) {
  try { localStorage.setItem(LAST_LOCATION_KEY, JSON.stringify(loc)); } catch { /* noop */ }
}

const HospitalMapModal = ({ hospitalName, onClose }: HospitalMapModalProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [coords, setCoords] = useState<{
    userLat: number; userLng: number; hospLat: number; hospLng: number;
  } | null>(null);
  const [nearbyHospitals, setNearbyHospitals] = useState<NearbyPlace[]>([]);
  const [nearbyPharmacies, setNearbyPharmacies] = useState<NearbyPlace[]>([]);
  const [manualCoords, setManualCoords] = useState<{ lat: number; lon: number } | null>(() => {
    const saved = loadSavedLocation();
    return saved ? { lat: saved.lat, lon: saved.lon } : null;
  });
  const [savedLabel, setSavedLabel] = useState<string | null>(() => loadSavedLocation()?.label ?? null);
  const [manualQuery, setManualQuery] = useState("");
  const [manualBusy, setManualBusy] = useState(false);
  const [manualError, setManualError] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "hospital" | "pharmacy">("all");
  const [visibleCount, setVisibleCount] = useState(12);
  const [retryNonce, setRetryNonce] = useState(0);
  const [pickerMode, setPickerMode] = useState(false);
  const [pickerCenter, setPickerCenter] = useState<{ lat: number; lon: number } | null>(null);
  const pickerMapRef = useRef<HTMLDivElement>(null);
  const pickerMapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    const map = L.map(mapRef.current).setView([13.0827, 80.2707], 12); // Default Chennai
    mapInstanceRef.current = map;

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    const userIcon = L.divIcon({
      html: '<div style="background:hsl(var(--primary));width:14px;height:14px;border-radius:50%;border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3)"></div>',
      iconSize: [14, 14],
      className: "",
    });

    const hospitalIcon = L.divIcon({
      html: '<div style="background:#ef4444;width:14px;height:14px;border-radius:50%;border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3)"></div>',
      iconSize: [14, 14],
      className: "",
    });

    const otherHospitalIcon = L.divIcon({
      html: '<div style="background:#f59e0b;width:11px;height:11px;border-radius:50%;border:2px solid white;box-shadow:0 2px 4px rgba(0,0,0,0.3)"></div>',
      iconSize: [11, 11],
      className: "",
    });

    const pharmacyIcon = L.divIcon({
      html: '<div style="background:#10b981;width:11px;height:11px;border-radius:50%;border:2px solid white;box-shadow:0 2px 4px rgba(0,0,0,0.3)"></div>',
      iconSize: [11, 11],
      className: "",
    });

    const initMap = async () => {
      try {
        let userLat: number;
        let userLng: number;
        if (manualCoords) {
          userLat = manualCoords.lat;
          userLng = manualCoords.lon;
        } else {
          const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
              enableHighAccuracy: true,
              timeout: 12000,
              maximumAge: 60000,
            });
          });
          userLat = pos.coords.latitude;
          userLng = pos.coords.longitude;
        }

        L.marker([userLat, userLng], { icon: userIcon })
          .addTo(map)
          .bindPopup("📍 Your Location")
          .openPopup();

        // Discover ALL hospitals, clinics & pharmacies within 10km via Overpass.
        // Includes node/way/relation and clinics so we surface enough places.
        const radius = 10000;
        const overpassQuery = `[out:json][timeout:25];(`
          + `node["amenity"~"^(hospital|clinic|doctors)$"](around:${radius},${userLat},${userLng});`
          + `way["amenity"~"^(hospital|clinic|doctors)$"](around:${radius},${userLat},${userLng});`
          + `relation["amenity"~"^(hospital|clinic|doctors)$"](around:${radius},${userLat},${userLng});`
          + `node["amenity"~"^(pharmacy|chemist)$"](around:${radius},${userLat},${userLng});`
          + `way["amenity"~"^(pharmacy|chemist)$"](around:${radius},${userLat},${userLng});`
          + `relation["amenity"~"^(pharmacy|chemist)$"](around:${radius},${userLat},${userLng});`
          + `node["shop"="chemist"](around:${radius},${userLat},${userLng});`
          + `);out center 300;`;
        // Try primary endpoint, then fall back to a mirror so results show reliably.
        const endpoints = [
          "https://overpass-api.de/api/interpreter",
          "https://overpass.kumi.systems/api/interpreter",
        ];
        let overpassData: { elements?: unknown[] } = {};
        for (const url of endpoints) {
          try {
            const r = await fetch(`${url}?data=${encodeURIComponent(overpassQuery)}`);
            if (!r.ok) continue;
            overpassData = await r.json();
            if ((overpassData.elements?.length ?? 0) > 0) break;
          } catch { /* try next */ }
        }
        const elements = (overpassData.elements || []) as Array<{
          lat?: number; lon?: number; center?: { lat: number; lon: number };
          tags?: { name?: string; amenity?: string; shop?: string; phone?: string; "contact:phone"?: string };
        }>;
        type Place = { lat: number; lon: number; name?: string; kind: "hospital" | "pharmacy"; phone?: string };
        const places: Place[] = elements
          .map((e) => ({
            lat: (e.lat ?? e.center?.lat) as number | undefined,
            lon: (e.lon ?? e.center?.lon) as number | undefined,
            name: e.tags?.name,
            amenity: e.tags?.amenity,
            shop: e.tags?.shop,
            phone: e.tags?.phone || e.tags?.["contact:phone"],
          }))
          .filter((e) => e.lat != null && e.lon != null)
          .map((e) => {
            const isPharm = e.amenity === "pharmacy" || e.amenity === "chemist" || e.shop === "chemist";
            const kind: "hospital" | "pharmacy" = isPharm ? "pharmacy" : "hospital";
            const place: Place = { lat: e.lat as number, lon: e.lon as number, name: e.name, kind };
            if (e.phone) place.phone = e.phone;
            return place;
          });

        const withDist = places.map((p) => ({
          ...p,
          distanceKm: haversine(userLat, userLng, p.lat, p.lon),
        }));
        // Strict 10km filter (Overpass `around` is great-circle, but enforce client-side too)
        const within10 = withDist.filter((p) => p.distanceKm <= 10);
        const hospitals = within10.filter((p) => p.kind === "hospital").sort((a, b) => a.distanceKm - b.distanceKm);
        const pharmacies = within10.filter((p) => p.kind === "pharmacy").sort((a, b) => a.distanceKm - b.distanceKm);

        setNearbyHospitals(hospitals.map((h) => ({ name: h.name || "Hospital", lat: h.lat, lon: h.lon, distanceKm: h.distanceKm, phone: h.phone, kind: "hospital" as const })));
        setNearbyPharmacies(pharmacies.map((h) => ({ name: h.name || "Pharmacy", lat: h.lat, lon: h.lon, distanceKm: h.distanceKm, phone: h.phone, kind: "pharmacy" as const })));

        let hospLat: number; let hospLng: number;
        if (hospitals.length > 0) {
          hospLat = hospitals[0].lat;
          hospLng = hospitals[0].lon;
        } else {
          hospLat = userLat + 0.02;
          hospLng = userLng + 0.02;
        }

        // Plot all secondary hospital markers
        hospitals.slice(1).forEach((h) => {
          L.marker([h.lat, h.lon], { icon: otherHospitalIcon })
            .addTo(map)
            .bindPopup(`🏥 ${h.name || "Hospital"} · ${h.distanceKm.toFixed(1)} km`);
        });
        // Plot pharmacies
        pharmacies.forEach((p) => {
          L.marker([p.lat, p.lon], { icon: pharmacyIcon })
            .addTo(map)
            .bindPopup(`💊 ${p.name || "Pharmacy"} · ${p.distanceKm.toFixed(1)} km`);
        });

        L.marker([hospLat, hospLng], { icon: hospitalIcon })
          .addTo(map)
          .bindPopup(`🏥 ${hospitals[0]?.name || hospitalName}`);

        setCoords({ userLat, userLng, hospLat, hospLng });

        // Get route from OSRM
        const routeRes = await fetch(
          `https://router.project-osrm.org/route/v1/driving/${userLng},${userLat};${hospLng},${hospLat}?overview=full&geometries=geojson`
        );
        const routeData = await routeRes.json();

        if (routeData.routes && routeData.routes.length > 0) {
          const route = routeData.routes[0];
          const coords = route.geometry.coordinates.map(
            (c: [number, number]) => [c[1], c[0]] as L.LatLngTuple
          );

          L.polyline(coords, {
            color: "hsl(210, 60%, 50%)",
            weight: 4,
            opacity: 0.8,
          }).addTo(map);

          const distKm = (route.distance / 1000).toFixed(1);
          const durMin = Math.round(route.duration / 60);
          const hours = Math.floor(durMin / 60);
          const mins = durMin % 60;

          setRouteInfo({
            distance: `${distKm} km`,
            duration: hours > 0 ? `${hours}h ${mins}m` : `${mins} min`,
          });

          map.fitBounds(L.polyline(coords).getBounds(), { padding: [40, 40] });
        } else {
          // No route, just fit both markers
          map.fitBounds(
            L.latLngBounds([userLat, userLng], [hospLat, hospLng]),
            { padding: [40, 40] }
          );
        }

        setLoading(false);
      } catch (err) {
        console.error("Map error:", err);
        const code = (err as GeolocationPositionError | undefined)?.code;
        if (code === 1) {
          setPermissionDenied(true);
          setError("Location access is blocked. Tap the lock icon in your browser's address bar → allow Location, then reload. Without location we can't pinpoint hospitals near you.");
        } else if (code === 2) {
          setError("Your location is unavailable right now. Move to an area with better GPS / network signal and try again.");
        } else if (code === 3) {
          setError("Getting your location timed out. Please try again — open this from outdoors if possible.");
        } else {
          setError("We couldn't load nearby places. Please check your connection and try again.");
        }
        setLoading(false);
      }
    };

    initMap();

    return () => {
      map.remove();
    };
  }, [hospitalName, manualCoords, retryNonce]);

  // Pin-picker map
  useEffect(() => {
    if (!pickerMode || !pickerMapRef.current) return;
    const start = manualCoords ?? { lat: 13.0827, lon: 80.2707 };
    const pmap = L.map(pickerMapRef.current).setView([start.lat, start.lon], 13);
    pickerMapInstanceRef.current = pmap;
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; OpenStreetMap',
    }).addTo(pmap);
    setPickerCenter(start);
    pmap.on("move", () => {
      const c = pmap.getCenter();
      setPickerCenter({ lat: c.lat, lon: c.lng });
    });
    // Try to seed with geolocation silently
    if (!manualCoords && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          pmap.setView([pos.coords.latitude, pos.coords.longitude], 14);
        },
        () => { /* ignore */ },
        { timeout: 5000 }
      );
    }
    return () => { pmap.remove(); pickerMapInstanceRef.current = null; };
  }, [pickerMode, manualCoords]);

  const allNearby = [...nearbyHospitals, ...nearbyPharmacies].sort((a, b) => a.distanceKm - b.distanceKm);
  const filteredNearby = filter === "all"
    ? allNearby
    : filter === "hospital"
      ? nearbyHospitals.slice().sort((a, b) => a.distanceKm - b.distanceKm)
      : nearbyPharmacies.slice().sort((a, b) => a.distanceKm - b.distanceKm);

  const submitManualLocation = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const q = manualQuery.trim();
    if (!q) return;
    setManualBusy(true);
    setManualError(null);
    try {
      // Accept "lat, lon" directly
      const m = q.match(/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/);
      if (m) {
        setLoading(true);
        setError(null);
      const lat = parseFloat(m[1]);
      const lon = parseFloat(m[2]);
      setManualCoords({ lat, lon });
      setSavedLabel(q);
      saveLocation({ lat, lon, label: q });
        return;
      }
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(q)}`,
        { headers: { "Accept-Language": "en" } }
      );
    const data = (await res.json()) as Array<{ lat: string; lon: string; display_name?: string }>;
      if (!data.length) {
        setManualError("Couldn't find that place. Try a city, postcode, or 'lat, lon'.");
        return;
      }
      setLoading(true);
      setError(null);
    const lat = parseFloat(data[0].lat);
    const lon = parseFloat(data[0].lon);
    setManualCoords({ lat, lon });
    setSavedLabel(data[0].display_name ?? q);
    saveLocation({ lat, lon, label: data[0].display_name ?? q });
    } catch {
      setManualError("Lookup failed. Check your connection and try again.");
    } finally {
      setManualBusy(false);
    }
  };

  const retryLocation = () => {
    setManualCoords(null);
    setSavedLabel(null);
    setError(null);
    setPermissionDenied(false);
    setLoading(true);
    setRetryNonce((n) => n + 1);
  };

  const confirmPin = () => {
    if (!pickerCenter) return;
    saveLocation({ lat: pickerCenter.lat, lon: pickerCenter.lon, label: "Pinned location" });
    setSavedLabel("Pinned location");
    setManualCoords(pickerCenter);
    setPickerMode(false);
    setError(null);
    setLoading(true);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="relative bg-card rounded-2xl shadow-xl w-full max-w-lg overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center gap-2 min-w-0">
              <MapPin className="w-5 h-5 text-primary shrink-0" />
              <h3 className="text-sm font-semibold text-foreground truncate">{hospitalName}</h3>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>

          {savedLabel && !error && (
            <div className="px-4 py-1.5 text-[11px] text-muted-foreground bg-secondary/40 border-b border-border flex items-center gap-1.5">
              <MapPin className="w-3 h-3" />
              <span className="truncate">Using saved location: {savedLabel}</span>
              <button
                onClick={retryLocation}
                className="ml-auto text-primary font-medium hover:underline inline-flex items-center gap-1"
                title="Use device location"
              >
                <Crosshair className="w-3 h-3" /> Use GPS
              </button>
            </div>
          )}

          {/* Route info */}
          {routeInfo && (
            <div className="flex items-center gap-4 px-4 py-3 bg-primary/5 border-b border-border">
              <div className="flex items-center gap-1.5">
                <Navigation className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">{routeInfo.distance}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground">{routeInfo.duration}</span>
              </div>
              {allNearby.length > 0 && (
                <span className="ml-auto text-[11px] text-muted-foreground">
                  {nearbyHospitals.length} hospitals · {nearbyPharmacies.length} pharmacies
                </span>
              )}
            </div>
          )}

          {/* Map */}
          <div className="relative w-full h-72">
            {loading && (
              <div className="absolute inset-0 z-10 flex items-center justify-center bg-card">
                <Loader2 className="w-6 h-6 animate-spin text-primary" />
              </div>
            )}
            {error && (
              <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-card p-6 gap-3">
                <AlertTriangle className="w-6 h-6 text-destructive" />
                <p className="text-sm text-muted-foreground text-center max-w-xs">{error}</p>
                <form onSubmit={submitManualLocation} className="w-full max-w-xs flex flex-col gap-2">
                  <label className="text-[11px] font-medium text-foreground">Enter your location manually</label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={manualQuery}
                      onChange={(e) => setManualQuery(e.target.value)}
                      placeholder="City, postcode, or lat, lon"
                      className="flex-1 px-2.5 py-1.5 text-xs rounded-md border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                    <button
                      type="submit"
                      disabled={manualBusy || !manualQuery.trim()}
                      className="px-2.5 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-medium disabled:opacity-50 inline-flex items-center gap-1"
                    >
                      {manualBusy ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
                      Find
                    </button>
                  </div>
                  {manualError && <p className="text-[10px] text-destructive">{manualError}</p>}
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={retryLocation}
                      className="flex-1 px-2.5 py-1.5 rounded-md bg-secondary text-secondary-foreground text-xs font-medium inline-flex items-center justify-center gap-1 hover:bg-secondary/80"
                    >
                      <RotateCw className="w-3 h-3" /> Try again
                    </button>
                    <button
                      type="button"
                      onClick={() => setPickerMode(true)}
                      className="flex-1 px-2.5 py-1.5 rounded-md bg-secondary text-secondary-foreground text-xs font-medium inline-flex items-center justify-center gap-1 hover:bg-secondary/80"
                    >
                      <MapPin className="w-3 h-3" /> Drop pin
                    </button>
                  </div>
                  {permissionDenied && (
                    <a
                      href={`https://www.google.com/maps/search/hospital+near+me`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] font-medium text-primary underline underline-offset-2 text-center"
                    >
                      Or open Google Maps instead
                    </a>
                  )}
                </form>
              </div>
            )}
            <div ref={mapRef} className="w-full h-full" />
          </div>

          {/* Map legend */}
          {!error && (
            <div className="px-4 py-2 border-t border-border flex items-center gap-3 flex-wrap text-[11px] text-muted-foreground">
              <span className="font-medium text-foreground">Legend:</span>
              <span className="flex items-center gap-1.5"><span className="inline-block w-2.5 h-2.5 rounded-full" style={{ background: "hsl(var(--primary))" }} />You</span>
              <span className="flex items-center gap-1.5"><span className="inline-block w-2.5 h-2.5 rounded-full bg-[#ef4444]" />Primary hospital</span>
              <span className="flex items-center gap-1.5"><span className="inline-block w-2.5 h-2.5 rounded-full bg-[#f59e0b]" />Other hospitals</span>
              <span className="flex items-center gap-1.5"><span className="inline-block w-2.5 h-2.5 rounded-full bg-[#10b981]" />Pharmacies</span>
            </div>
          )}

          {/* Nearby list with distances + tap-to-call / directions */}
          {!error && allNearby.length > 0 && coords && (
            <>
              <div className="px-4 py-2 border-t border-border flex items-center gap-1.5 text-[11px]">
                {([
                  { id: "all", label: `All (${allNearby.length})` },
                  { id: "hospital", label: `🏥 Hospitals (${nearbyHospitals.length})` },
                  { id: "pharmacy", label: `💊 Pharmacies (${nearbyPharmacies.length})` },
                ] as const).map((f) => (
                  <button
                    key={f.id}
                    onClick={() => { setFilter(f.id); setVisibleCount(12); }}
                    className={`px-2 py-1 rounded-full transition-colors ${
                      filter === f.id
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
              <div className="max-h-56 overflow-y-auto border-t border-border divide-y divide-border">
                {filteredNearby.slice(0, visibleCount).map((p, i) => (
                  <div key={`${p.kind}-${i}-${p.lat}-${p.lon}`} className="flex items-center gap-2 px-4 py-2.5">
                    <span
                      className="inline-block w-2.5 h-2.5 rounded-full shrink-0"
                      style={{
                        background:
                          p.kind === "pharmacy"
                            ? "#10b981"
                            : filter !== "pharmacy" && i === 0 && p.kind === "hospital"
                            ? "#ef4444"
                            : "#f59e0b",
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground truncate">{p.name}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {p.kind === "pharmacy" ? "💊 Pharmacy" : "🏥 Hospital"} · {p.distanceKm.toFixed(1)} km
                      </p>
                    </div>
                    {p.phone && (
                      <a
                        href={`tel:${p.phone.replace(/\s+/g, "")}`}
                        className="p-1.5 rounded-md hover:bg-secondary text-primary"
                        aria-label={`Call ${p.name}`}
                        title="Call"
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </a>
                    )}
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&origin=${coords.userLat},${coords.userLng}&destination=${p.lat},${p.lon}&travelmode=driving`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-md hover:bg-secondary text-primary"
                      aria-label={`Directions to ${p.name}`}
                      title="Directions"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
                {filteredNearby.length > visibleCount && (
                  <button
                    onClick={() => setVisibleCount((c) => c + 12)}
                    className="w-full py-2.5 text-xs font-medium text-primary hover:bg-secondary transition-colors"
                  >
                    Show more ({filteredNearby.length - visibleCount} remaining)
                  </button>
                )}
              </div>
            </>
          )}

          {/* Open in maps */}
          <div className="p-3 border-t border-border">
            <a
              href={
                coords
                  ? `https://www.google.com/maps/dir/?api=1&origin=${coords.userLat},${coords.userLng}&destination=${coords.hospLat},${coords.hospLng}&travelmode=driving`
                  : `https://www.google.com/maps/search/${encodeURIComponent(hospitalName)}`
              }
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center py-2.5 px-4 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity"
            >
              Open Directions in Google Maps
            </a>
          </div>

          {pickerMode && (
            <div className="absolute inset-0 z-20 bg-card flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h3 className="text-sm font-semibold text-foreground">Drop a pin at your location</h3>
                <button onClick={() => setPickerMode(false)} className="p-1.5 rounded-lg hover:bg-secondary">
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
              <div className="relative flex-1 min-h-[280px]">
                <div ref={pickerMapRef} className="absolute inset-0" />
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                  <MapPin className="w-8 h-8 text-primary drop-shadow-lg -translate-y-4" fill="hsl(var(--primary))" />
                </div>
              </div>
              <div className="p-3 border-t border-border flex items-center gap-2">
                <p className="text-[11px] text-muted-foreground flex-1">
                  {pickerCenter ? `${pickerCenter.lat.toFixed(4)}, ${pickerCenter.lon.toFixed(4)}` : "Move the map to position the pin"}
                </p>
                <button
                  onClick={confirmPin}
                  disabled={!pickerCenter}
                  className="px-3 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-medium disabled:opacity-50"
                >
                  Use this location
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default HospitalMapModal;
