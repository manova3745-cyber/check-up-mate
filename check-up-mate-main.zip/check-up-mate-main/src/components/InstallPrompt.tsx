import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, Siren, X, Share } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const STORAGE_KEY = "medicare-install-dismissed";

function isStandalone() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    // iOS Safari
    (window.navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

function isIos() {
  return /iphone|ipad|ipod/i.test(window.navigator.userAgent) && !/crios|fxios/i.test(window.navigator.userAgent);
}

/**
 * Auto-shows an "Add to Home Screen" prompt so the SOS button is reachable
 * from the user's mobile home screen like a native app.
 */
const InstallPrompt = () => {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [open, setOpen] = useState(false);
  const [iosHint, setIosHint] = useState(false);

  useEffect(() => {
    if (isStandalone()) return;
    if (sessionStorage.getItem(STORAGE_KEY) === "1") return;

    const onBip = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
      setOpen(true);
    };
    window.addEventListener("beforeinstallprompt", onBip);

    // iOS Safari has no beforeinstallprompt — show manual instructions
    const t = window.setTimeout(() => {
      if (!isStandalone() && isIos() && sessionStorage.getItem(STORAGE_KEY) !== "1") {
        setIosHint(true);
        setOpen(true);
      }
    }, 1500);

    return () => {
      window.removeEventListener("beforeinstallprompt", onBip);
      window.clearTimeout(t);
    };
  }, []);

  const dismiss = () => {
    sessionStorage.setItem(STORAGE_KEY, "1");
    setOpen(false);
  };

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice;
    dismiss();
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ ease: [0.2, 0, 0, 1] }}
          className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[200] w-[min(92vw,420px)]"
        >
          <div className="rounded-2xl border border-border bg-card shadow-2xl p-4 flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0">
              <Siren className="w-5 h-5 text-destructive" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground">Add MediCare AI to your Home Screen</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                One-tap access to the SOS button during emergencies — works like a real app.
              </p>
              {iosHint ? (
                <p className="text-[11px] text-muted-foreground mt-2 inline-flex items-center gap-1">
                  Tap <Share className="w-3 h-3 inline" /> Share, then <b>Add to Home Screen</b>.
                </p>
              ) : (
                <button
                  onClick={install}
                  className="mt-3 inline-flex items-center gap-1.5 h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90"
                >
                  <Download className="w-4 h-4" /> Install app
                </button>
              )}
            </div>
            <button onClick={dismiss} className="p-1 rounded-md hover:bg-secondary text-muted-foreground" aria-label="Dismiss">
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default InstallPrompt;