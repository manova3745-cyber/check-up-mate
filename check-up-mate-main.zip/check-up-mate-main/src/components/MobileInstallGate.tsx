import { useEffect, useState } from "react";
import { Download, Share, Smartphone } from "lucide-react";

interface BIP extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

function isMobile() {
  const ua = navigator.userAgent;
  if (/iPhone|iPad|iPod|Android/i.test(ua)) return true;
  // treat coarse-pointer + small viewport as mobile too
  return window.matchMedia("(pointer: coarse)").matches && window.innerWidth < 900;
}

function isIos() {
  return /iPhone|iPad|iPod/i.test(navigator.userAgent);
}

function isStandalone() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
    document.referrer.startsWith("android-app://")
  );
}

function isInIframe() {
  try { return window.self !== window.top; } catch { return true; }
}

/**
 * Blocks mobile/tablet users from using the web version unless the app
 * is launched as an installed PWA (standalone display mode).
 * Desktop browsers and the Lovable preview iframe are allowed through.
 */
const MobileInstallGate = ({ children }: { children: React.ReactNode }) => {
  const [blocked, setBlocked] = useState(false);
  const [deferred, setDeferred] = useState<BIP | null>(null);

  useEffect(() => {
    // Never block inside the editor preview or on desktop
    if (isInIframe()) return;
    if (!isMobile()) return;
    if (isStandalone()) return;
    setBlocked(true);

    const onBip = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BIP);
    };
    window.addEventListener("beforeinstallprompt", onBip);
    return () => window.removeEventListener("beforeinstallprompt", onBip);
  }, []);

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice;
  };

  if (!blocked) return <>{children}</>;

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="max-w-md w-full bg-card border border-border rounded-2xl shadow-xl p-6 text-center">
        <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <Smartphone className="w-7 h-7 text-primary" />
        </div>
        <h1 className="text-xl font-bold text-foreground">Install the app to continue</h1>
        <p className="text-sm text-muted-foreground mt-2">
          MediCare AI is available on mobile only as an installed app. This keeps your symptom data fast,
          offline-ready, and the SOS button one tap away.
        </p>

        {deferred ? (
          <button
            onClick={install}
            className="mt-6 w-full h-11 inline-flex items-center justify-center gap-2 rounded-lg bg-primary text-primary-foreground font-semibold hover:opacity-90"
          >
            <Download className="w-4 h-4" /> Install app
          </button>
        ) : isIos() ? (
          <div className="mt-6 text-sm text-left bg-secondary/50 rounded-xl p-4 space-y-2">
            <p className="font-semibold text-foreground">Install on iPhone / iPad</p>
            <ol className="list-decimal pl-5 space-y-1 text-muted-foreground">
              <li>Tap the <Share className="inline w-4 h-4 -mt-0.5" /> Share button in Safari.</li>
              <li>Choose <b>Add to Home Screen</b>.</li>
              <li>Open MediCare AI from your home screen.</li>
            </ol>
          </div>
        ) : (
          <div className="mt-6 text-sm text-left bg-secondary/50 rounded-xl p-4 space-y-2">
            <p className="font-semibold text-foreground">Install on Android</p>
            <ol className="list-decimal pl-5 space-y-1 text-muted-foreground">
              <li>Open the browser menu (⋮).</li>
              <li>Tap <b>Install app</b> or <b>Add to Home Screen</b>.</li>
              <li>Launch MediCare AI from your home screen.</li>
            </ol>
          </div>
        )}

        <p className="text-[11px] text-muted-foreground mt-4">
          On a laptop or desktop? Just open this site there — no install needed.
        </p>
      </div>
    </div>
  );
};

export default MobileInstallGate;