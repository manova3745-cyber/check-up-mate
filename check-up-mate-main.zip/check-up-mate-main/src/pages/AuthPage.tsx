import { useState } from "react";
import { motion } from "framer-motion";
import { Activity } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import type { Language } from "@/lib/i18n";
import { translations } from "@/lib/i18n";
import { lovable } from "@/integrations/lovable/index";

interface AuthPageProps {
  language: Language;
  onToggleLanguage: () => void;
}

const AuthPage = ({ language, onToggleLanguage }: AuthPageProps) => {
  const [mode, setMode] = useState<"login" | "signup" | "forgot">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [weightKg, setWeightKg] = useState("");
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();

  const T = translations[language];

  const handleGoogleSignIn = async () => {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result?.error) {
      toast.error(String(result.error));
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || (mode !== "forgot" && !password.trim())) return;
    setLoading(true);

    if (mode === "forgot") {
      const { supabase } = await import("@/integrations/supabase/client");
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      setLoading(false);
      if (error) {
        toast.error(error.message);
      } else {
        toast.success(T.resetEmailSent as string);
        setMode("login");
      }
      return;
    }

    if (mode === "login") {
      const { error } = await signIn(email, password);
      if (error) toast.error(error);
    } else {
      const { error } = await signUp(email, password, displayName || email);
      if (error) {
        toast.error(error);
      } else {
        // Save DOB to profile after signup
        if (dateOfBirth || weightKg) {
          const { supabase } = await import("@/integrations/supabase/client");
          const { data: { user: newUser } } = await supabase.auth.getUser();
          if (newUser) {
            const updates: { date_of_birth?: string; weight_kg?: number } = {};
            if (dateOfBirth) updates.date_of_birth = dateOfBirth;
            if (weightKg) updates.weight_kg = parseFloat(weightKg);
            await supabase.from("profiles").update(updates).eq("user_id", newUser.id);
          }
        }
        toast.success("Check your email to confirm your account!");
      }
    }
    setLoading(false);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.2, 0, 0, 1] }}
        className="w-full max-w-sm"
      >
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
            <Activity className="w-7 h-7 text-primary" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-foreground">
            {mode === "forgot" ? T.resetPassword : mode === "login" ? T.loginTitle : T.signupTitle}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {mode === "forgot" ? T.resetPasswordSubtitle : mode === "login" ? T.loginSubtitle : T.signupSubtitle}
          </p>
        </div>

        {/* Google Sign In */}
        {mode !== "forgot" && (
          <>
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full py-3 bg-card border border-border text-foreground font-medium rounded-xl disabled:opacity-50 transition-opacity flex items-center justify-center gap-3 hover:bg-secondary"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              {T.continueWithGoogle}
            </motion.button>

            <div className="flex items-center gap-3 my-5">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">{T.orContinueWith}</span>
              <div className="flex-1 h-px bg-border" />
            </div>
          </>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "signup" && (
            <>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder={T.displayName as string}
                className="w-full px-4 py-3 bg-secondary text-foreground placeholder:text-muted-foreground rounded-xl text-[15px] outline-none focus:ring-2 focus:ring-primary/20"
                maxLength={100}
              />
              <input
                type="date"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                placeholder={T.dateOfBirth as string}
                className="w-full px-4 py-3 bg-secondary text-foreground placeholder:text-muted-foreground rounded-xl text-[15px] outline-none focus:ring-2 focus:ring-primary/20"
                max={new Date().toISOString().split("T")[0]}
              />
              <input
                type="number"
                value={weightKg}
                onChange={(e) => setWeightKg(e.target.value)}
                placeholder={T.weightKg as string}
                min={1}
                max={300}
                step={0.1}
                className="w-full px-4 py-3 bg-secondary text-foreground placeholder:text-muted-foreground rounded-xl text-[15px] outline-none focus:ring-2 focus:ring-primary/20"
              />
            </>
          )}
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder={T.email as string}
            required
            className="w-full px-4 py-3 bg-secondary text-foreground placeholder:text-muted-foreground rounded-xl text-[15px] outline-none focus:ring-2 focus:ring-primary/20"
            maxLength={255}
          />
          {mode !== "forgot" && (
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={T.password as string}
              required
              minLength={6}
              className="w-full px-4 py-3 bg-secondary text-foreground placeholder:text-muted-foreground rounded-xl text-[15px] outline-none focus:ring-2 focus:ring-primary/20"
            />
          )}
          <motion.button
            whileTap={{ scale: 0.97 }}
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-xl disabled:opacity-50 transition-opacity"
          >
            {loading ? "..." : mode === "forgot" ? T.sendResetLink : mode === "login" ? T.login : T.signup}
          </motion.button>
        </form>

        {/* Toggle */}
        <div className="mt-6 text-center space-y-2">
          {mode === "login" && (
            <button onClick={() => setMode("forgot")} className="text-sm text-primary hover:underline block mx-auto">
              {T.forgotPassword}
            </button>
          )}
          {mode === "forgot" ? (
            <button onClick={() => setMode("login")} className="text-sm text-muted-foreground">
              {T.backToLogin}
            </button>
          ) : (
            <p className="text-sm text-muted-foreground">
              {mode === "login" ? T.noAccount : T.hasAccount}{" "}
              <button
                onClick={() => setMode(mode === "login" ? "signup" : "login")}
                className="text-primary font-medium hover:underline"
              >
                {mode === "login" ? T.signup : T.login}
              </button>
            </p>
          )}
        </div>

        {/* Language toggle */}
        <div className="mt-6 flex justify-center">
          <button
            onClick={onToggleLanguage}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg bg-secondary"
          >
            {language === "en" ? "தமிழ்" : "English"}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default AuthPage;