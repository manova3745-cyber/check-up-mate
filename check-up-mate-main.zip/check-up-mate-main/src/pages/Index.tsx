import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Activity, LogOut, Plus, History, Globe, BarChart3, Calculator, Pill } from "lucide-react";
import { useNavigate } from "react-router-dom";
import ChatMessage from "@/components/chat/ChatMessage";
import SymptomPills from "@/components/chat/SymptomPills";
import ChatInput from "@/components/chat/ChatInput";
import DisclaimerBar from "@/components/chat/DisclaimerBar";
import DosageCalculator from "@/components/chat/DosageCalculator";
import EmergencyButton from "@/components/chat/EmergencyButton";
import ProfilePopover from "@/components/chat/ProfilePopover";
import InstallPrompt from "@/components/InstallPrompt";
import { streamChat, type Msg } from "@/lib/chat";
import { translations, type Language } from "@/lib/i18n";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ConversationSummary {
  id: string;
  title: string;
  created_at: string;
}

const Index = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [language, setLanguage] = useState<Language>("en");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showPills, setShowPills] = useState(true);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<ConversationSummary[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [userAge, setUserAge] = useState<number | null>(null);
  const [userWeight, setUserWeight] = useState<number | null>(null);
  const [userHeight, setUserHeight] = useState<number | null>(null);
  const [userDob, setUserDob] = useState<Date | null>(null);
  const [showCalc, setShowCalc] = useState(false);
  const [intakeOpen, setIntakeOpen] = useState(false);

  const T = translations[language];

  // Load user language preference and age
  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("preferred_language, date_of_birth, weight_kg, height_cm")
      .eq("user_id", user.id)
      .single()
      .then(({ data }) => {
        if (data?.preferred_language === "ta") setLanguage("ta");
        if (data?.date_of_birth) {
          const birth = new Date(data.date_of_birth);
          setUserDob(birth);
          const today = new Date();
          let age = today.getFullYear() - birth.getFullYear();
          const m = today.getMonth() - birth.getMonth();
          if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
          setUserAge(age);
        }
        if (data?.weight_kg) setUserWeight(Number(data.weight_kg));
        if (data?.height_cm) setUserHeight(Number(data.height_cm));
      });
  }, [user]);

  // Set welcome message based on language
  useEffect(() => {
    if (!conversationId) {
      setMessages([{ role: "assistant", content: T.welcome as string }]);
      setShowPills(true);
    }
  }, [language, T.welcome, conversationId]);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, []);

  useEffect(() => scrollToBottom(), [messages, scrollToBottom]);

  const toggleLanguage = async () => {
    const newLang = language === "en" ? "ta" : "en";
    setLanguage(newLang);
    if (user) {
      await supabase.from("profiles").update({ preferred_language: newLang }).eq("user_id", user.id);
    }
  };

  const loadHistory = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("conversations")
      .select("id, title, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(20);
    setHistory(data || []);
    setShowHistory(true);
  };

  const loadConversation = async (convId: string) => {
    const { data } = await supabase
      .from("messages")
      .select("role, content")
      .eq("conversation_id", convId)
      .order("created_at", { ascending: true });
    if (data) {
      setMessages(data.map((m) => ({ role: m.role as "user" | "assistant", content: m.content })));
      setConversationId(convId);
      setShowPills(false);
      setShowHistory(false);
    }
  };

  const startNewChat = () => {
    setConversationId(null);
    setMessages([{ role: "assistant", content: T.welcome as string }]);
    setShowPills(true);
    setShowHistory(false);
  };

  const sendMessage = async (input: string) => {
    // Intake gate: require age + height before symptom prediction
    if (userAge === null || userHeight === null) {
      setIntakeOpen(true);
      toast.message(language === "ta"
        ? "துல்லியமான பரிந்துரைக்கு உங்கள் வயது மற்றும் உயரத்தை பகிரவும்."
        : "Please share your age and height for accurate suggestions.");
      return;
    }
    const userMsg: Msg = { role: "user", content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsLoading(true);
    setShowPills(false);

    // Create conversation if new
    let convId = conversationId;
    if (!convId && user) {
      const { data } = await supabase
        .from("conversations")
        .insert({ user_id: user.id, title: input.slice(0, 60), language })
        .select("id")
        .single();
      if (data) {
        convId = data.id;
        setConversationId(convId);
      }
    }

    // Save user message
    if (convId) {
      await supabase.from("messages").insert({
        conversation_id: convId,
        role: "user",
        content: input,
      });
    }

    let assistantText = "";
    const upsert = (chunk: string) => {
      assistantText += chunk;
      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last?.role === "assistant" && prev.length > newMessages.length) {
          return prev.map((m, i) => (i === prev.length - 1 ? { ...m, content: assistantText } : m));
        }
        return [...prev, { role: "assistant", content: assistantText }];
      });
      scrollToBottom();
    };

    try {
      await streamChat({
        messages: newMessages,
        language,
        userAge,
        userWeight,
        userHeight,
        onDelta: upsert,
        onDone: async () => {
          setIsLoading(false);
          // Save assistant message
          if (convId && assistantText) {
            await supabase.from("messages").insert({
              conversation_id: convId,
              role: "assistant",
              content: assistantText,
            });
          }
        },
        onError: (err) => {
          toast.error(err);
          setIsLoading(false);
        },
      });
    } catch {
      toast.error("Failed to connect. Please try again.");
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: [0.2, 0, 0, 1] }}
        className="flex items-center gap-3 px-4 sm:px-6 py-4 border-b border-border bg-card"
      >
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Activity className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-semibold tracking-tight text-foreground">{T.appName}</h1>
          <p className="text-xs text-muted-foreground">{T.appSubtitle}</p>
        </div>
        <div className="flex items-center gap-1">
          {user && (
            <ProfilePopover
              userId={user.id}
              language={language}
              dob={userDob}
              weight={userWeight}
              height={userHeight}
              age={userAge}
              onChange={({ dob, weight, height, age }) => {
                setUserDob(dob);
                setUserWeight(weight);
                setUserHeight(height);
                setUserAge(age);
              }}
            />
          )}
          <button onClick={toggleLanguage} className="p-2 rounded-lg hover:bg-secondary transition-colors" title={T.language as string}>
            <Globe className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => setShowCalc(true)} className="p-2 rounded-lg hover:bg-secondary transition-colors" title="Dosage calculator">
            <Calculator className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => navigate("/dashboard")} className="p-2 rounded-lg hover:bg-secondary transition-colors" title={T.dashboard as string}>
            <BarChart3 className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={() => navigate("/pharmacies")} className="p-2 rounded-lg hover:bg-secondary transition-colors" title="Pharmacies & prices">
            <Pill className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={startNewChat} className="p-2 rounded-lg hover:bg-secondary transition-colors" title={T.newChat as string}>
            <Plus className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={loadHistory} className="p-2 rounded-lg hover:bg-secondary transition-colors" title={T.history as string}>
            <History className="w-4 h-4 text-muted-foreground" />
          </button>
          <button onClick={signOut} className="p-2 rounded-lg hover:bg-secondary transition-colors" title={T.logout as string}>
            <LogOut className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </motion.header>

      {/* Disclaimer */}
      <DisclaimerBar language={language} />

      {/* History sidebar overlay */}
      <AnimatePresence>
        {showHistory && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-background/80 backdrop-blur-sm flex justify-end"
            onClick={() => setShowHistory(false)}
          >
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ ease: [0.2, 0, 0, 1] }}
              className="w-72 h-full bg-card border-l border-border p-4 overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <h2 className="text-sm font-semibold text-foreground mb-4">{T.history}</h2>
              {history.length === 0 ? (
                <p className="text-sm text-muted-foreground">No conversations yet.</p>
              ) : (
                <div className="space-y-2">
                  {history.map((conv) => (
                    <button
                      key={conv.id}
                      onClick={() => loadConversation(conv.id)}
                      className="w-full text-left p-3 rounded-xl hover:bg-secondary transition-colors"
                    >
                      <p className="text-sm font-medium text-foreground truncate">{conv.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {new Date(conv.created_at).toLocaleDateString()}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
        {messages.map((msg, i) => (
          <ChatMessage key={i} role={msg.role} content={msg.content} />
        ))}

        {showPills && (
          <SymptomPills
            symptoms={T.symptoms as unknown as string[]}
            onSelect={sendMessage}
            disabled={isLoading}
          />
        )}

        {isLoading && messages[messages.length - 1]?.role === "user" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
            <div className="px-5 py-4 bg-card rounded-[20px] rounded-bl-lg" style={{ boxShadow: "var(--card-shadow)" }}>
              <div className="flex gap-1.5">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 rounded-full bg-muted-foreground/40"
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.15 }}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Input */}
      <ChatInput
        onSend={sendMessage}
        disabled={isLoading}
        placeholder={T.inputPlaceholder as string}
      />

      <EmergencyButton language={language} />
      <InstallPrompt />

      {/* Intake gate modal: prompt for age + height before first symptom prediction */}
      <AnimatePresence>
        {intakeOpen && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[120] bg-background/85 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setIntakeOpen(false)}
          >
            <motion.div
              initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }}
              className="bg-card rounded-2xl shadow-xl w-full max-w-sm p-5 border border-border"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-base font-semibold text-foreground">
                {language === "ta" ? "முதலில் சில விவரங்கள்" : "A few details first"}
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                {language === "ta"
                  ? "சரியான மருந்து அளவு மற்றும் ஆலோசனைக்கு உங்கள் பிறந்த தேதி, எடை மற்றும் உயரத்தை சேமிக்கவும்."
                  : "To give you accurate dosages and advice, please save your date of birth, weight and height."}
              </p>
              <ul className="text-xs text-muted-foreground mt-2 space-y-1 list-disc pl-5">
                <li>{language === "ta" ? "வயது (பிறந்த தேதியில் இருந்து)" : "Age (from date of birth)"}</li>
                <li>{language === "ta" ? "உயரம் (செமீ)" : "Height (cm)"}</li>
                <li>{language === "ta" ? "எடை (கிலோ) — விருப்பமானது" : "Weight (kg) — optional but recommended"}</li>
              </ul>
              <div className="mt-4 flex justify-end">
                <button
                  onClick={() => setIntakeOpen(false)}
                  className="px-4 h-10 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90"
                >
                  {language === "ta" ? "சுயவிவரத்தை திற" : "Open profile"}
                </button>
              </div>
              <p className="text-[11px] text-muted-foreground mt-3 text-center">
                {language === "ta"
                  ? "தலைப்பின் வலது மூலையில் உள்ள சுயவிவர பேட்ஜை தட்டவும்."
                  : "Tap the profile chip in the top-right to enter your details."}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {showCalc && (
        <DosageCalculator
          defaultAge={userAge}
          defaultWeight={userWeight}
          language={language}
          onClose={() => setShowCalc(false)}
          onAskAI={(prompt) => sendMessage(prompt)}
        />
      )}
    </div>
  );
};

export default Index;