import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Plus, Trash2, ShieldAlert } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

type Pharmacy = { id: string; name: string; country: string; state: string; district: string; address: string | null; phone: string | null };
type Medicine = { id: string; name: string; generic_name: string | null; category: string; form: string | null };
type Price = { id: string; pharmacy_id: string; medicine_id: string; price: number; currency: string; pack_size: string | null; in_stock: boolean };

const AdminPharmaciesPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [prices, setPrices] = useState<Price[]>([]);
  const [selectedPharma, setSelectedPharma] = useState<string>("");

  // forms
  const [pf, setPf] = useState({ name: "", country: "India", state: "", district: "", address: "", phone: "" });
  const [mf, setMf] = useState({ name: "", generic_name: "", category: "allopathy", form: "tablet" });
  const [prf, setPrf] = useState({ medicine_id: "", price: "", currency: "INR", pack_size: "", in_stock: true });

  useEffect(() => {
    if (!user) return;
    supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle()
      .then(({ data }) => setIsAdmin(!!data));
  }, [user]);

  const reload = async () => {
    const [a, b, c] = await Promise.all([
      supabase.from("pharmacies").select("*").order("name"),
      supabase.from("medicines").select("*").order("name"),
      supabase.from("medicine_prices").select("*"),
    ]);
    setPharmacies(a.data || []);
    setMedicines(b.data || []);
    setPrices(c.data || []);
  };

  useEffect(() => { if (isAdmin) reload(); }, [isAdmin]);

  if (isAdmin === null) return <div className="p-6 text-sm text-muted-foreground">Checking access…</div>;

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-md text-center bg-card border border-border rounded-2xl p-6">
          <ShieldAlert className="w-10 h-10 text-destructive mx-auto" />
          <h1 className="text-lg font-semibold mt-3">Admin access required</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Your account does not have admin permissions. Ask an existing admin to grant you the <code>admin</code> role
            in the <code>user_roles</code> table.
          </p>
          <button onClick={() => navigate("/")} className="mt-4 h-10 px-4 rounded-md bg-primary text-primary-foreground text-sm font-semibold">Back</button>
        </div>
      </div>
    );
  }

  const addPharmacy = async () => {
    if (!pf.name || !pf.country || !pf.state || !pf.district) return toast.error("Name, country, state, district required");
    const { error } = await supabase.from("pharmacies").insert(pf);
    if (error) return toast.error(error.message);
    toast.success("Pharmacy added");
    setPf({ name: "", country: "India", state: "", district: "", address: "", phone: "" });
    reload();
  };

  const addMedicine = async () => {
    if (!mf.name) return toast.error("Name required");
    const { error } = await supabase.from("medicines").insert(mf);
    if (error) return toast.error(error.message);
    toast.success("Medicine added");
    setMf({ name: "", generic_name: "", category: "allopathy", form: "tablet" });
    reload();
  };

  const addPrice = async () => {
    if (!selectedPharma || !prf.medicine_id || !prf.price) return toast.error("Pharmacy, medicine and price required");
    const { error } = await supabase.from("medicine_prices").upsert(
      { ...prf, price: Number(prf.price), pharmacy_id: selectedPharma },
      { onConflict: "pharmacy_id,medicine_id" }
    );
    if (error) return toast.error(error.message);
    toast.success("Price saved");
    setPrf({ medicine_id: "", price: "", currency: "INR", pack_size: "", in_stock: true });
    reload();
  };

  const del = async (table: "pharmacies" | "medicines" | "medicine_prices", id: string) => {
    if (!confirm("Delete this entry?")) return;
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) return toast.error(error.message);
    reload();
  };

  const pharmaPrices = prices.filter((p) => p.pharmacy_id === selectedPharma);
  const medName = (id: string) => medicines.find((m) => m.id === id)?.name || id;

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-8">
      <button onClick={() => navigate(-1)} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="w-4 h-4" /> Back
      </button>
      <h1 className="text-2xl font-bold">Admin · Pharmacies & Prices</h1>

      {/* Pharmacies */}
      <section className="bg-card border border-border rounded-2xl p-4">
        <h2 className="font-semibold mb-3">Pharmacies</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-3">
          {(["name", "country", "state", "district", "address", "phone"] as const).map((k) => (
            <input
              key={k}
              placeholder={k}
              value={pf[k]}
              onChange={(e) => setPf({ ...pf, [k]: e.target.value })}
              className="h-10 px-3 rounded-lg border border-border bg-background text-sm"
            />
          ))}
        </div>
        <button onClick={addPharmacy} className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold">
          <Plus className="w-4 h-4" /> Add pharmacy
        </button>
        <div className="mt-4 divide-y divide-border border border-border rounded-lg max-h-64 overflow-y-auto">
          {pharmacies.map((p) => (
            <div key={p.id} className="p-2 flex items-center justify-between text-sm">
              <span className="truncate">
                <b>{p.name}</b> · {p.district}, {p.state}, {p.country}
              </span>
              <button onClick={() => del("pharmacies", p.id)} className="p-1 hover:bg-secondary rounded">
                <Trash2 className="w-4 h-4 text-destructive" />
              </button>
            </div>
          ))}
          {pharmacies.length === 0 && <p className="p-3 text-xs text-muted-foreground">None yet.</p>}
        </div>
      </section>

      {/* Medicines */}
      <section className="bg-card border border-border rounded-2xl p-4">
        <h2 className="font-semibold mb-3">Medicines</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <input placeholder="Name" value={mf.name} onChange={(e) => setMf({ ...mf, name: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm" />
          <input placeholder="Generic name" value={mf.generic_name} onChange={(e) => setMf({ ...mf, generic_name: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm" />
          <select value={mf.category} onChange={(e) => setMf({ ...mf, category: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm">
            <option value="allopathy">Allopathy</option>
            <option value="siddha">Siddha</option>
            <option value="ayurveda">Ayurveda</option>
            <option value="unani">Unani</option>
          </select>
          <input placeholder="Form (tablet, syrup...)" value={mf.form} onChange={(e) => setMf({ ...mf, form: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm" />
        </div>
        <button onClick={addMedicine} className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold">
          <Plus className="w-4 h-4" /> Add medicine
        </button>
        <div className="mt-4 divide-y divide-border border border-border rounded-lg max-h-64 overflow-y-auto">
          {medicines.map((m) => (
            <div key={m.id} className="p-2 flex items-center justify-between text-sm">
              <span className="truncate">
                <b>{m.name}</b> {m.generic_name && `(${m.generic_name})`} · {m.category} {m.form && `· ${m.form}`}
              </span>
              <button onClick={() => del("medicines", m.id)} className="p-1 hover:bg-secondary rounded">
                <Trash2 className="w-4 h-4 text-destructive" />
              </button>
            </div>
          ))}
          {medicines.length === 0 && <p className="p-3 text-xs text-muted-foreground">None yet.</p>}
        </div>
      </section>

      {/* Prices */}
      <section className="bg-card border border-border rounded-2xl p-4">
        <h2 className="font-semibold mb-3">Set prices</h2>
        <select value={selectedPharma} onChange={(e) => setSelectedPharma(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-border bg-background text-sm mb-3">
          <option value="">Select a pharmacy…</option>
          {pharmacies.map((p) => <option key={p.id} value={p.id}>{p.name} — {p.district}, {p.state}</option>)}
        </select>
        {selectedPharma && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <select value={prf.medicine_id} onChange={(e) => setPrf({ ...prf, medicine_id: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm">
                <option value="">Medicine…</option>
                {medicines.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
              <input type="number" step="0.01" placeholder="Price" value={prf.price} onChange={(e) => setPrf({ ...prf, price: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm" />
              <input placeholder="Currency" value={prf.currency} onChange={(e) => setPrf({ ...prf, currency: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm" />
              <input placeholder="Pack size" value={prf.pack_size} onChange={(e) => setPrf({ ...prf, pack_size: e.target.value })} className="h-10 px-3 rounded-lg border border-border bg-background text-sm" />
              <label className="inline-flex items-center gap-2 text-sm">
                <input type="checkbox" checked={prf.in_stock} onChange={(e) => setPrf({ ...prf, in_stock: e.target.checked })} /> In stock
              </label>
            </div>
            <button onClick={addPrice} className="mt-3 inline-flex items-center gap-1.5 h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-semibold">
              <Plus className="w-4 h-4" /> Save price
            </button>
            <div className="mt-4 divide-y divide-border border border-border rounded-lg max-h-64 overflow-y-auto">
              {pharmaPrices.map((p) => (
                <div key={p.id} className="p-2 flex items-center justify-between text-sm">
                  <span className="truncate">
                    <b>{medName(p.medicine_id)}</b> · {p.currency} {Number(p.price).toFixed(2)} {p.pack_size && `· ${p.pack_size}`} {!p.in_stock && "· OUT"}
                  </span>
                  <button onClick={() => del("medicine_prices", p.id)} className="p-1 hover:bg-secondary rounded">
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </button>
                </div>
              ))}
              {pharmaPrices.length === 0 && <p className="p-3 text-xs text-muted-foreground">No prices yet for this pharmacy.</p>}
            </div>
          </>
        )}
      </section>
    </div>
  );
};

export default AdminPharmaciesPage;