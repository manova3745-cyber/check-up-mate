import { useState } from "react";
import { motion } from "framer-motion";
import { Activity } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import type { Language } from "@/lib/i18n";
import { translations } from "@/lib/i18n";

interface ResetPasswordPageProps {
  language: Language;
}

const ResetPasswordPage = ({ language }: ResetPasswordPageProps) => {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const T = translations[language];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim() || password.length < 6) return;
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
    } else {
      toast.success(T.passwordUpdated as string);
      navigate("/");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
            <Activity className="w-7 h-7 text-primary" />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-foreground">{T.setNewPasswordTitle}</h1>
          <p className="text-sm text-muted-foreground mt-1">{T.setNewPasswordSubtitle}</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={T.newPassword as string}
            required
            minLength={6}
            className="w-full px-4 py-3 bg-secondary text-foreground placeholder:text-muted-foreground rounded-xl text-[15px] outline-none focus:ring-2 focus:ring-primary/20"
          />
          <motion.button
            whileTap={{ scale: 0.97 }}
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-xl disabled:opacity-50"
          >
            {loading ? "..." : T.updatePassword}
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
};

export default ResetPasswordPage;
