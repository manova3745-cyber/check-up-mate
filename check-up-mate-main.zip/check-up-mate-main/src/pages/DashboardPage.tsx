import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Activity, ArrowLeft, BarChart3, Calendar } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { translations, type Language } from "@/lib/i18n";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

interface SymptomLog {
  id: string;
  symptom: string;
  severity: string | null;
  logged_at: string;
  notes: string | null;
}

type TimeRange = "7d" | "30d" | "all";

const DashboardPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [logs, setLogs] = useState<SymptomLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<TimeRange>("30d");
  const [language, setLanguage] = useState<Language>("en");
  const T = translations[language];

  // Load language preference
  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("preferred_language")
      .eq("user_id", user.id)
      .single()
      .then(({ data }) => {
        if (data?.preferred_language === "ta") setLanguage("ta");
      });
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const fetchLogs = async () => {
      setLoading(true);
      let query = supabase
        .from("symptom_logs")
        .select("id, symptom, severity, logged_at, notes")
        .eq("user_id", user.id)
        .order("logged_at", { ascending: true });

      if (timeRange === "7d") {
        const d = new Date();
        d.setDate(d.getDate() - 7);
        query = query.gte("logged_at", d.toISOString());
      } else if (timeRange === "30d") {
        const d = new Date();
        d.setDate(d.getDate() - 30);
        query = query.gte("logged_at", d.toISOString());
      }

      const { data } = await query;
      setLogs(data || []);
      setLoading(false);
    };
    fetchLogs();
  }, [user, timeRange]);

  const frequencyData = Object.entries(
    logs.reduce<Record<string, number>>((acc, log) => {
      acc[log.symptom] = (acc[log.symptom] || 0) + 1;
      return acc;
    }, {})
  )
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const timelineData = Object.entries(
    logs.reduce<Record<string, number>>((acc, log) => {
      const day = new Date(log.logged_at).toLocaleDateString("en-US", { month: "short", day: "numeric" });
      acc[day] = (acc[day] || 0) + 1;
      return acc;
    }, {})
  ).map(([date, count]) => ({ date, count }));

  const uniqueSymptoms = new Set(logs.map((l) => l.symptom)).size;

  const rangeLabels: Record<TimeRange, string> = {
    "7d": T.last7Days as string,
    "30d": T.last30Days as string,
    all: T.allTime as string,
  };

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto">
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-3 px-4 sm:px-6 py-4 border-b border-border bg-card"
      >
        <button onClick={() => navigate("/")} className="p-2 rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="w-5 h-5 text-muted-foreground" />
        </button>
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Activity className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-semibold tracking-tight text-foreground">{T.symptomDashboard}</h1>
          <p className="text-xs text-muted-foreground">{T.symptomDashboardSubtitle}</p>
        </div>
      </motion.header>

      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
        {/* Time range tabs */}
        <div className="flex gap-2">
          {(["7d", "30d", "all"] as TimeRange[]).map((r) => (
            <button
              key={r}
              onClick={() => setTimeRange(r)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                timeRange === r
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {rangeLabels[r]}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-20">
            <BarChart3 className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
            <p className="text-muted-foreground">{T.noSymptomData}</p>
          </div>
        ) : (
          <>
            {/* Stats cards */}
            <div className="grid grid-cols-2 gap-4">
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-5 rounded-2xl bg-card border border-border"
                style={{ boxShadow: "var(--card-shadow)" }}
              >
                <p className="text-sm text-muted-foreground">{T.totalLogged}</p>
                <p className="text-3xl font-bold text-foreground mt-1">{logs.length}</p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 }}
                className="p-5 rounded-2xl bg-card border border-border"
                style={{ boxShadow: "var(--card-shadow)" }}
              >
                <p className="text-sm text-muted-foreground">{T.uniqueSymptoms}</p>
                <p className="text-3xl font-bold text-foreground mt-1">{uniqueSymptoms}</p>
              </motion.div>
            </div>

            {/* Frequency bar chart */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="p-5 rounded-2xl bg-card border border-border"
              style={{ boxShadow: "var(--card-shadow)" }}
            >
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 className="w-4 h-4 text-primary" />
                <h2 className="text-sm font-semibold text-foreground">{T.symptomFrequency}</h2>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={frequencyData} layout="vertical" margin={{ left: 80, right: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
                    <YAxis
                      dataKey="name"
                      type="category"
                      tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                      width={75}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "12px",
                        fontSize: "13px",
                      }}
                    />
                    <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Timeline line chart */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="p-5 rounded-2xl bg-card border border-border"
              style={{ boxShadow: "var(--card-shadow)" }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="w-4 h-4 text-primary" />
                <h2 className="text-sm font-semibold text-foreground">{T.symptomTimeline}</h2>
              </div>
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timelineData} margin={{ left: 10, right: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
                    <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "12px",
                        fontSize: "13px",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="count"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--primary))", r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          </>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;