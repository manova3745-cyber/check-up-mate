import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, MapPin, Pill, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Pharmacy = {
  id: string;
  name: string;
  country: string;
  state: string;
  district: string;
  address: string | null;
  phone: string | null;
};

type PriceRow = {
  id: string;
  price: number;
  currency: string;
  pack_size: string | null;
  in_stock: boolean;
  pharmacy_id: string;
  medicines: { name: string; generic_name: string | null; category: string; form: string | null } | null;
};

const PharmaciesPage = () => {
  const navigate = useNavigate();
  const [country, setCountry] = useState<string>("");
  const [stateName, setStateName] = useState<string>("");
  const [district, setDistrict] = useState<string>("");
  const [allLocations, setAllLocations] = useState<Pharmacy[]>([]);
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [selected, setSelected] = useState<Pharmacy | null>(null);
  const [prices, setPrices] = useState<PriceRow[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase
      .from("pharmacies")
      .select("id, name, country, state, district, address, phone")
      .then(({ data }) => setAllLocations(data || []));
  }, []);

  const countries = useMemo(
    () => Array.from(new Set(allLocations.map((p) => p.country))).sort(),
    [allLocations]
  );
  const states = useMemo(
    () => Array.from(new Set(allLocations.filter((p) => p.country === country).map((p) => p.state))).sort(),
    [allLocations, country]
  );
  const districts = useMemo(
    () =>
      Array.from(
        new Set(
          allLocations.filter((p) => p.country === country && p.state === stateName).map((p) => p.district)
        )
      ).sort(),
    [allLocations, country, stateName]
  );

  useEffect(() => {
    if (!country || !stateName || !district) {
      setPharmacies([]);
      return;
    }
    setPharmacies(
      allLocations.filter(
        (p) => p.country === country && p.state === stateName && p.district === district
      )
    );
  }, [country, stateName, district, allLocations]);

  const loadPrices = async (p: Pharmacy) => {
    setSelected(p);
    setLoading(true);
    const { data } = await supabase
      .from("medicine_prices")
      .select("id, price, currency, pack_size, in_stock, pharmacy_id, medicines(name, generic_name, category, form)")
      .eq("pharmacy_id", p.id)
      .order("price", { ascending: true });
    setPrices((data as unknown as PriceRow[]) || []);
    setLoading(false);
  };

  const filteredPrices = useMemo(() => {
    if (!search.trim()) return prices;
    const q = search.toLowerCase();
    return prices.filter(
      (r) =>
        r.medicines?.name.toLowerCase().includes(q) ||
        r.medicines?.generic_name?.toLowerCase().includes(q)
    );
  }, [prices, search]);

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6">
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4"
      >
        <ArrowLeft className="w-4 h-4" /> Back
      </button>

      <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
        <Pill className="w-6 h-6 text-primary" /> Pharmacies & Medicine Prices
      </h1>
      <p className="text-sm text-muted-foreground mt-1">
        Browse tablet and medicine prices by location.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-5">
        <select
          value={country}
          onChange={(e) => { setCountry(e.target.value); setStateName(""); setDistrict(""); setSelected(null); }}
          className="h-10 px-3 rounded-lg border border-border bg-background text-sm"
        >
          <option value="">Country</option>
          {countries.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select
          value={stateName}
          disabled={!country}
          onChange={(e) => { setStateName(e.target.value); setDistrict(""); setSelected(null); }}
          className="h-10 px-3 rounded-lg border border-border bg-background text-sm disabled:opacity-50"
        >
          <option value="">State</option>
          {states.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select
          value={district}
          disabled={!stateName}
          onChange={(e) => { setDistrict(e.target.value); setSelected(null); }}
          className="h-10 px-3 rounded-lg border border-border bg-background text-sm disabled:opacity-50"
        >
          <option value="">District</option>
          {districts.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
      </div>

      {allLocations.length === 0 && (
        <div className="mt-6 p-4 rounded-xl border border-dashed border-border text-sm text-muted-foreground text-center">
          No pharmacies have been added yet. An admin can add them from the admin page.
        </div>
      )}

      {pharmacies.length > 0 && (
        <div className="mt-5 space-y-2">
          <p className="text-xs uppercase tracking-wide text-muted-foreground font-semibold">
            {pharmacies.length} pharmacy{pharmacies.length !== 1 ? "ies" : ""} found
          </p>
          {pharmacies.map((p) => (
            <button
              key={p.id}
              onClick={() => loadPrices(p)}
              className={`w-full text-left p-3 rounded-xl border transition-colors ${
                selected?.id === p.id ? "border-primary bg-primary/5" : "border-border hover:bg-secondary"
              }`}
            >
              <p className="font-medium text-foreground">{p.name}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3" /> {p.address || `${p.district}, ${p.state}`}
              </p>
              {p.phone && <p className="text-xs text-muted-foreground mt-0.5">📞 {p.phone}</p>}
            </button>
          ))}
        </div>
      )}

      {selected && (
        <div className="mt-6">
          <h2 className="text-lg font-semibold text-foreground">Prices at {selected.name}</h2>
          <div className="relative mt-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search medicine..."
              className="w-full h-10 pl-9 pr-3 rounded-lg border border-border bg-background text-sm"
            />
          </div>

          {loading ? (
            <p className="text-sm text-muted-foreground mt-3">Loading prices...</p>
          ) : filteredPrices.length === 0 ? (
            <p className="text-sm text-muted-foreground mt-3">No medicines listed for this pharmacy yet.</p>
          ) : (
            <div className="mt-3 border border-border rounded-xl overflow-hidden divide-y divide-border">
              {filteredPrices.map((r) => (
                <div key={r.id} className="p-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium text-foreground truncate">{r.medicines?.name}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {r.medicines?.generic_name && `${r.medicines.generic_name} · `}
                      {r.medicines?.category}
                      {r.medicines?.form && ` · ${r.medicines.form}`}
                      {r.pack_size && ` · ${r.pack_size}`}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-foreground">
                      {r.currency} {Number(r.price).toFixed(2)}
                    </p>
                    <p className={`text-[11px] ${r.in_stock ? "text-emerald-600" : "text-destructive"}`}>
                      {r.in_stock ? "In stock" : "Out of stock"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
          <p className="text-[11px] text-muted-foreground mt-3 text-center">
            Prices are indicative. This is not a medical diagnosis — please consult a doctor before purchasing medicine.
          </p>
        </div>
      )}
    </div>
  );
};

export default PharmaciesPage;