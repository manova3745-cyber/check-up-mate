CREATE POLICY "Users can update messages of their conversations"
ON public.messages
FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM public.conversations
  WHERE conversations.id = messages.conversation_id
    AND conversations.user_id = auth.uid()
))
WITH CHECK (EXISTS (
  SELECT 1 FROM public.conversations
  WHERE conversations.id = messages.conversation_id
    AND conversations.user_id = auth.uid()
));

CREATE POLICY "Users can delete messages of their conversations"
ON public.messages
FOR DELETE
USING (EXISTS (
  SELECT 1 FROM public.conversations
  WHERE conversations.id = messages.conversation_id
    AND conversations.user_id = auth.uid()
));